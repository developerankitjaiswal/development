<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin\AdminloginController;
use App\Http\Controllers\admin\AdminController;
use App\Http\Controllers\admin\BannerController;
use App\Http\Controllers\admin\CategoryController;
use App\Http\Controllers\admin\SubcategoryController;
use App\Http\Controllers\admin\ProductController;
use App\Http\Controllers\admin\PageController;
use App\Http\Controllers\admin\TestimonialController;
use App\Http\Controllers\admin\BlogController;
use App\Http\Controllers\FrontController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

/* Front Route */
Route::get('/',[FrontController::class,'index'])->name('index');
Route::get('/product/{slug}',[FrontController::class,'product'])->name('product');
Route::get('/detail/{slug}',[FrontController::class,'productdetail'])->name('detail');
Route::get('/about',[FrontController::class,'about'])->name('about');
Route::get('/blog',[FrontController::class,'blog'])->name('blog');
Route::get('/blog/{slug}',[FrontController::class,'blogdetail'])->name('blogdetail');
Route::get('/faq',[FrontController::class,'faq'])->name('faq');
Route::get('/contact',[FrontController::class,'contact'])->name('contact');
Route::get('/return-policy',[FrontController::class,'return_policy'])->name('return');
Route::get('/term-policy',[FrontController::class,'term_policy'])->name('term');
Route::get('/privacy-policy',[FrontController::class,'privacy_policy'])->name('privacy');
Route::post('/contact',[FrontController::class,'sendContact'])->name('contact.send');
Route::get('/dealer',[FrontController::class,'dealer'])->name('dealer');
Route::post('/dealer',[FrontController::class,'sendDealer'])->name('dealer.send');

/* Admin Route */
Route::group(['prefix' => 'admin'], function(){
    /* for guest */
    Route::group(['middleware' => 'admin.guest'], function(){
        Route::get('/',[AdminloginController::class,'index'])->name('admin');
        Route::post('/authenticate',[AdminloginController::class,'authenticate'])->name('admin.authenticate');
    });
    /* for admin */
    Route::group(['middleware' => 'admin.auth'], function(){
        Route::get('/dashboard',[AdminController::class,'index'])->name('admin.dashboard');
        Route::get('/logout',[AdminController::class,'logout'])->name('admin.logout');
        /* CKEDITOR */ 
        Route::post('/ckeditor-upload',[AdminController::class,'ckeditor_upload'])->name('ckeditor.upload');
        /* BANNER */ 
        Route::get('/banner',[BannerController::class,'index'])->name('banner.index');
        Route::post('/banner',[BannerController::class,'store_create'])->name('banner.store');
        Route::get('/banner/{banner}/edit',[BannerController::class,'edit_banner'])->name('banner.edit');
        Route::post('/banner/{banner}',[BannerController::class,'update_banner'])->name('banner.update');
        Route::get('/banner/status',[BannerController::class,'status_banner'])->name('banner.status');
        Route::get('/banner/{category}',[BannerController::class,'delete_banner'])->name('banner.delete');
        /* CATEGORY */ 
        Route::get('/category',[CategoryController::class,'index'])->name('category.index');
        Route::get('/category/create',[CategoryController::class,'create'])->name('category.create');
        Route::post('/category',[CategoryController::class,'store_create'])->name('category.store');
        Route::get('/category/{category}/edit',[CategoryController::class,'edit_category'])->name('category.edit');
        Route::post('/category/{category}',[CategoryController::class,'update_category'])->name('category.update');
        Route::get('/category/status',[CategoryController::class,'status_category'])->name('category.status');
        Route::get('/category/{category}',[CategoryController::class,'delete_category'])->name('category.delete');
        /* SUB-CATEGORY */  
        Route::get('/subcategory',[SubcategoryController::class,'index'])->name('subcategory.index');
        Route::get('/subcategory/create',[SubcategoryController::class,'create'])->name('subcategory.create');
        Route::post('/subcategory',[SubcategoryController::class,'store_create'])->name('subcategory.store');
        Route::get('/subcategory/{category}/edit',[SubcategoryController::class,'edit_category'])->name('subcategory.edit');
        Route::post('/subcategory/{category}',[SubcategoryController::class,'update_category'])->name('subcategory.update');
        Route::get('/subcategory/status',[SubcategoryController::class,'status_category'])->name('subcategory.status');
        Route::get('/subcategory/{category}',[SubcategoryController::class,'delete_category'])->name('subcategory.delete');
        /* PRODUCTS */ 
        Route::get('/getsubcategory',[ProductController::class,'getsubcategory'])->name('products.getsubcategory');
        Route::get('/product',[ProductController::class,'index'])->name('product.index');
        Route::get('/product/create',[ProductController::class,'create'])->name('product.create');
        Route::post('/product',[ProductController::class,'store_product'])->name('product.store');
        Route::get('/product/{product}/edit',[ProductController::class,'edit_product'])->name('product.edit');
        Route::post('/product/{product}',[ProductController::class,'update_product'])->name('product.update');
        Route::get('/product/status',[ProductController::class,'status_product'])->name('product.status');
        Route::get('/product/{product}',[ProductController::class,'delete_product'])->name('product.delete');
        /* PAGES */
        Route::get('/about',[PageController::class,'about'])->name('about.view');
        Route::post('/about',[PageController::class,'store_about'])->name('about.add');
        Route::get('/termpolicy',[PageController::class,'termpolicy'])->name('termpolicy.view');
        Route::post('/termpolicy',[PageController::class,'store_termpolicy'])->name('termpolicy.add');
        Route::get('/returnpolicy',[PageController::class,'returnpolicy'])->name('returnpolicy.view');
        Route::post('/returnpolicy',[PageController::class,'store_returnpolicy'])->name('returnpolicy.add');
        Route::get('/privacypolicy',[PageController::class,'privacypolicy'])->name('privacypolicy.view');
        Route::post('/privacypolicy',[PageController::class,'store_privacypolicy'])->name('privacypolicy.add');
        /* TESTIMONIAL */
        Route::get('/testimonial',[TestimonialController::class,'index'])->name('testimonial.index');
        Route::get('/testimonial/create',[TestimonialController::class,'create'])->name('testimonial.create');
        Route::post('/testimonial',[TestimonialController::class,'store_testimonial'])->name('testimonial.store');
        Route::get('/testimonial/{testimonial}/edit',[TestimonialController::class,'edit_testimonial'])->name('testimonial.edit');
        Route::post('/testimonial/{testimonial}',[TestimonialController::class,'update_testimonial'])->name('testimonial.update');
        Route::get('/testimonial/status',[TestimonialController::class,'status_testimonial'])->name('testimonial.status');
        Route::get('/testimonial/{testimonial}',[TestimonialController::class,'delete_testimonial'])->name('testimonial.delete');
        /* BLOG */
        Route::get('/blog',[BlogController::class,'index'])->name('blog.index');
        Route::get('/blog/create',[BlogController::class,'create'])->name('blog.create');
        Route::post('/blog',[BlogController::class,'store_blog'])->name('blog.store');
        Route::get('/blog/{blog}/edit',[BlogController::class,'edit_blog'])->name('blog.edit');
        Route::post('/blog/{blog}',[BlogController::class,'update_blog'])->name('blog.update');
        Route::get('/blog/status',[BlogController::class,'status_blog'])->name('blog.status');
        Route::get('/blog/{blog}',[BlogController::class,'delete_blog'])->name('blog.delete');
    });
    /* for admin */
});