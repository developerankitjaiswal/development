@extends('front.layout.app')
@section('title', $blogdetail->metatitle)
@section('meta-keyword', $blogdetail->metakeyword)
@section('meta-desc', $blogdetail->metadescription)
@section('content')
    <div class="breadcrumb__area theme-bg-2 pt-30 pb-30">
       <div class="container">
          <div class="row">
             <div class="col-lg-12">
                <div class="tp-breadcrumb__content text-center">
                   <h4 class="tp-breadcrumb__title">Our Blogs</h4>
                   <div class="tp-breadcrumb__list">
                      <span style="color:white;"><a href="{{ route('blog') }}">Blog </a></span>
                      <span class="dvdr">/</span>
                      <span style="color:white;">{{ $blogdetail->name }}</span>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </div>
    <!-- blog-details-area-start -->
     <section class="blog-details-area pt-50 pb-50">
        <div class="container">
           <div class="row">
              <div class="col-lg-12">
                 <div class="tp-blog-details__thumb text-center">
                    <img src="{{asset('uploads/blog/'.$blogdetail->thumbnail.'')}}" alt="">
                 </div>
              </div>
           </div>
           <div class="row">
              <div class="col-xl-10 col-lg-12">
                 <div class="tp-blog-details__wrapper">
                    <div class="tp-blog-details__content">
                       <div class="tpblog__entry-wap mb-5">
                          <span class="cat-links"><a href="#">Bahety Overseas</a></span>
                          <span class="post-data"><a href="#">{{ formatBlogDate($blogdetail->created_at) }}</a></span>
                       </div>
                       <h2 class="tp-blog-details__title mb-25">{{ $blogdetail->name }}</h2>
                       {!! $blogdetail->description !!}
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </section>
    <!-- blog-details-area-end -->
@endsection