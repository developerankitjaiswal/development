@extends('front.layout.app')
@section('title', 'Contact')
@section('content')
   <!-- breadcrumb-area-start -->
   <div class="breadcrumb__area theme-bg-2 pt-50 pb-55">
      <div class="container">
         <div class="row">
            <div class="col-lg-12">
               <div class="tp-breadcrumb__content text-center">
                  <h4 class="tp-breadcrumb__title">Contact Us</h4>
                  <div class="tp-breadcrumb__list">
                     <span style="color:white;"><a href="{{ route('index') }}">Home</a></span>
                     <span class="dvdr">/</span>
                     <span style="color:white;">Contact Us</span>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- breadcrumb-area-end -->

   <!-- location-area-start -->
   <div class="location-area grey-bg pt-80 pb-80">
      <div class="container">
         <div class="row">
            
            <div class="col-lg-6">
               <div class="tpcontactmap mb-30">
                  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3505.335055144738!2d77.27632957537715!3d28.529647175721102!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce21dbcffffff%3A0x9b7ac86c50fbe42f!2sBahety%20Overseas%20Private%20Limited!5e0!3m2!1sen!2sin!4v1689701207927!5m2!1sen!2sin" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" width="600" height="350"></iframe>
               </div>
            </div>

            <div class="col-lg-6">
               <div class="tplocation mb-30">
                  <div class="tplocation__content">
                  <h4 class="tpform__title">LEAVE A REPLY</h4>
                        <p>Your email address will not be published. Required fields are marked *</p>
                  <div class="tpform__box">
                     <form id="contactForm">
                     @csrf
                        <div id="msg-box" style="font-size: 14px;"></div>
                        <div class="row gx-7">
                           <div class="col-lg-6">
                              <div class="tpform__input mb-20">
                                 <input type="text" placeholder="Your Name *" id="uname" name="uname">
                              </div>
                           </div>
                           <div class="col-lg-6">
                              <div class="tpform__input mb-20">
                                 <input type="text" placeholder="Phone *" id="uphone" name="uphone">
                              </div>
                           </div>
                           <div class="col-lg-12">
                              <div class="tpform__input mb-20">
                                 <input type="email" placeholder="Your Email *" id="uemail" name="uemail">
                              </div>
                           </div>
                           <div class="col-lg-6">
                              <div class="tpform__input mb-20">
                                 <input type="text" placeholder="Subject *" id="usubject" name="usubject">
                              </div>
                           </div>
                           <div class="col-lg-6">
                              <div class="tpform__input mb-20">
                                 <input type="text" placeholder="State *" id="ustate" name="ustate">
                              </div>
                           </div>
                           <div class="col-lg-12">
                              <div class="tpform__textarea">
                                 <textarea name="message" placeholder="Message *" id="umessage" name="umessage"></textarea>
                                 <button type="button" id="sendenquiry" class="show_enquiry">Send message</button>
                                 <button class="loding" style="display: none;"><i class="fa fa-spinner fa-spin"></i> Please Wait....</button>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </div>
   <!-- location-area-end -->
   @endsection
   @section('custom-javascript')
   <script>
   $(document).on('click', '#sendenquiry', function() {
      jQuery("#msg-box").css('display', 'none');
      var uname = $('#uname').val();
      var uphone = $('#uphone').val();
      var uemail = $('#uemail').val();
      var usubject = $('#usubject').val();
      var ustate = $('#ustate').val();
      var umessage = $('#umessage').val();
      var csrfToken = $('meta[name="csrf-token"]').attr('content');
      umessage = umessage.trim();
      $('#uname').removeClass('is-invalid');
      $('#uphone').removeClass('is-invalid');
      $('#uemail').removeClass('is-invalid');
      $('#usubject').removeClass('is-invalid');
      $('#ustate').removeClass('is-invalid');
      $('#umessage').removeClass('is-invalid');
      if (uname == "") {
         $("#msg-box").html('<div class="alert alert-danger" role="alert">Enter your name</div>');
         $("#msg-box").css('display', 'block');
         $('#uname').addClass('is-invalid');
         $('#uname').focus();
         return false;
      } else if (!uname.match(/^[a-zA-Z ]*$/)) {
         $("#msg-box").html('<div class="alert alert-danger" role="alert">Name should be alphabetic</div>');
         $("#msg-box").css('display', 'block');
         $('#uname').addClass('is-invalid');
         $('#uname').focus();
         return false;
      } else if (uphone == "") {
         $("#msg-box").html('<div class="alert alert-danger" role="alert">Please provide a phone number</div>');
         $("#msg-box").css('display', 'block');
         $('#uphone').addClass('is-invalid');
         $('#uphone').focus();
         return false;
      } else if ($('#uphone').val().length != 10) {
         $("#msg-box").html('<div class="alert alert-danger" role="alert">Mobile number must be 10 digits.</div>');
         $("#msg-box").css('display', 'block');
         $('#uphone').addClass('is-invalid');
         $('#uphone').focus();
         return false;
      } else if (!uphone.match(/^[6-9]\d{2}\d{3}\d{4}$/)) {
         $("#msg-box").html('<div class="alert alert-danger" role="alert">Mobile number is not valid!</div>');
         $("#msg-box").css('display', 'block');
         $('#uphone').addClass('is-invalid');
         $('#uphone').focus();
         return false;
      } else if (uemail == "") {
         $("#msg-box").html('<div class="alert alert-danger" role="alert">Please enter your email</div>');
         $("#msg-box").css('display', 'block');
         $('#uemail').addClass('is-invalid');
         $('#uemail').focus();
         return false;
      } else if (!uemail.match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/)) {
         $("#msg-box").html('<div class="alert alert-danger" role="alert">Please enter a valid email address</div>');
         $("#msg-box").css('display', 'block');
         $('#uemail').addClass('is-invalid');
         $('#uemail').focus();
         return false;
      } else if (usubject == "") {
         $("#msg-box").html('<div class="alert alert-danger" role="alert">Enter your subject</div>');
         $("#msg-box").css('display', 'block');
         $('#usubject').addClass('is-invalid');
         $('#usubject').focus();
         return false;
      } else if (ustate == "") {
         $("#msg-box").html('<div class="alert alert-danger" role="alert">Enter your state</div>');
         $("#msg-box").css('display', 'block');
         $('#ustate').addClass('is-invalid');
         $('#ustate').focus();
         return false;
      } else if (umessage == "") {
         $("#msg-box").html('<div class="alert alert-danger" role="alert">Enter your message</div>');
         $("#msg-box").css('display', 'block');
         $('#umessage').addClass('is-invalid');
         $('#umessage').focus();
         return false;
      } else {
         $('.show_enquiry').hide();
         $('.loding').show();
         $.ajax({
            url: "{{ route('contact.send') }}", 
            method: "POST",
            data: {
               name: uname,
               email: uemail,
               phone: uphone,
               subject: usubject,
               state: ustate,
               message: umessage,
               _token: csrfToken,
            },
            success: function(data) {
               if (data.status == 1) {
                  $("#msg-box").html('<div class="alert alert-success" role="alert">Thank you!. Your message is successfully sent...</div>');
                  $("#msg-box").css('display', 'block');
                  $('.show_enquiry').show();
                  $('.loding').hide();
                  $('#contactForm')[0].reset();
               } else if (data.status == 0) {
                  $("#msg-box").html('<div class="alert alert-danger" role="alert">We are sorry, but something went wrong</div>');
                  $("#msg-box").css('display', 'block');
                  $('.show_enquiry').show();
                  $('.loding').hide();
               }
            },
            error: function(xhr, status, error) {
               console.error(xhr);
            }
         });
      }
   });
   </script>
@endsection