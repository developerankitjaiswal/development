@extends('front.layout.app')
@section("title","Return Policy")
@section('content') 
<!-- breadcrumb-area-start -->
<div class="breadcrumb__area grey-bg pt-50 pb-55">
    <div class="container">
       <div class="row">
          <div class="col-lg-12">
             <div class="tp-breadcrumb__content text-center">
                <h4 class="tp-breadcrumb__title">{{ $returndata->title }}</h4>
                <div class="tp-breadcrumb__list">
                   <span class="tp-breadcrumb__active"><a href="{{ route('index') }}">Home</a></span>
                   <span class="dvdr">/</span>
                   <span>{{ $returndata->title }}</span>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>
<!-- breadcrumb-area-end -->
<!-- about-area-start -->
    <section class="about-area pt-100 pb-60">
            <div class="container">
            <div class="row align-items-center">
                @if(!empty($returndata->image))
                <div class="col-lg-6">
                    <div class="tpabout__inner-thumb-2 p-relative mb-30">
                        <img src="{{asset('uploads/other/'.$returndata->image.'')}}" alt="">
                    </div>
                </div>
                @endif
                @if(!empty($returndata->image))
                    <div class="col-lg-6">
                @else 
                    <div class="col-lg-12">
                @endif
                    <div class="tpabout__inner-2 mb-30">
                        {!! $returndata->description !!}
                    </div>
                </div>
            </div>
            </div>
    </section>
<!-- about-area-end -->
@endsection