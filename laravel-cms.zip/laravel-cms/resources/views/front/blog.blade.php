@extends('front.layout.app')
@section('title', 'Our Blogs')
@section('content')
<style>
   .basic-pagination ul li a:hover, .basic-pagination ul li a.current, .basic-pagination ul li span:hover, .basic-pagination ul li.active {
      background: var(--tp-heading-secondary);
      border-color: var(--tp-heading-secondary);
      color: #fff;
      border-radius: 25px;
   }
</style>
 <!-- breadcrumb-area-start -->
 <div class="breadcrumb__area theme-bg-2 pt-50 pb-55">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <div class="tp-breadcrumb__content text-center">
               <h4 class="tp-breadcrumb__title">Our Blogs</h4>
               <div class="tp-breadcrumb__list">
                  <span style="color:white;"><a href="{{ route('index') }}">Home</a></span>
                  <span class="dvdr">/</span>
                  <span style="color:white;">Our Blogs</span>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- breadcrumb-area-end -->
         <!-- blog-area-start -->
         <section class="blog-area grey-bg pt-80">
            <div class="container">
            @if(count($showblogs) > 0)    
               <div class="row">
                  @foreach($showblogs as $blogs)
                  <div class="col-lg-4">
                     <div class="tpblog__item tpblog__item-2 mb-20">
                        <div class="tpblog__thumb fix">
                           <a href="{{ route('blogdetail', $blogs->slug) }}"><img src="{{asset('uploads/blog/'.$blogs->thumbnail.'')}}" alt=""></a>
                        </div>
                        <div class="tpblog__wrapper">
                           <div class="tpblog__entry-wap">
                              <span class="cat-links"><a href="#">Bahety Overseas</a></span>
                              <span class="post-data"><a href="#">{{ formatBlogDate($blogs->created_at) }}</a></span>
                           </div>
                           <h4 class="tpblog__title"><a href="{{ route('blogdetail', $blogs->slug) }}">{{ $blogs->name }}</a></h4>
                           <p> {!!  getBlogDetail($blogs->description) !!}</p>
                           <div class="tpblog__details">
                              <a href="{{ route('blogdetail', $blogs->slug) }}">Continue reading <i class="icon-chevrons-right"></i> </a>
                           </div>
                        </div>
                     </div>
                  </div>
                  @endforeach
                  
                  
                  <div class="col-lg-12">
                     <div class="basic-pagination text-center mb-80">
                        {{-- <nav>
                           <ul>
                              <li>
                                 <span class="current">1</span>
                              </li>
                              <li>
                                 <a href="blog.html">2</a>
                              </li>
                              <li>
                                 <a href="blog.html">3</a>
                              </li>
                              <li>
                                 <a href="blog.html">
                                    <i class="icon-chevrons-right"></i>
                                 </a>
                              </li>
                           </ul>
                         </nav> --}}
                         {{ $showblogs->links('pagination::default') }}
                     </div>
                  </div>
                  
               </div>
               @else
                    <div class="row">
                       <p class="text-center"> No Blogs available </p>
                    </div>
                @endif
            </div>
         </section>
         <!-- blog-area-end -->
@endsection