@include('front.layout.header')   
   
  @yield('content')
  
@include('front.layout.footer')  
