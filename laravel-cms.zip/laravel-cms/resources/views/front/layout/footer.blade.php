<!-- feature-area-start -->
<section class="feature-area mainfeature__bg grey-bg pt-50 pb-40" data-background="{{ asset('asset/img/shape/footer-shape-1.svg') }}">
            <!--<div class="container">-->
            <!--    <div class="mainfeature__border pb-15">-->
            <!--        <div class="row row-cols-lg-5 row-cols-md-3 row-cols-2">-->
            <!--            <div class="col">-->
            <!--                <div class="mainfeature__item text-center mb-30">-->
            <!--                    <div class="mainfeature__icon">-->
            <!--                        <img src="{{ asset('asset/img/icon/choose-icon1.svg') }}" alt="">-->
            <!--                    </div>-->
            <!--                    <div class="mainfeature__content">-->
            <!--                        <h4 class="mainfeature__title">100% Fresh Products</h4>-->
            <!--                        <p>From Farm to you: Pure, Delicious, and 100% Fresh!</p>-->
            <!--                    </div>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="col">-->
            <!--                <div class="mainfeature__item text-center mb-30">-->
            <!--                    <div class="mainfeature__icon">-->
            <!--                        <img src="{{ asset('asset/img/icon/choose-icon2.svg') }}" alt="">-->
            <!--                    </div>-->
            <!--                    <div class="mainfeature__content">-->
            <!--                        <h4 class="mainfeature__title">Long Term Suppliers</h4>-->
            <!--                        <p>Working with long-term suppliers & established partners who have the same vision, experience & quality promise</p>-->
            <!--                    </div>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="col">-->
            <!--                <div class="mainfeature__item text-center mb-30">-->
            <!--                    <div class="mainfeature__icon">-->
            <!--                        <img src="{{ asset('asset/img/icon/choose-icon3.svg') }}" alt="">-->
            <!--                    </div>-->
            <!--                    <div class="mainfeature__content">-->
            <!--                        <h4 class="mainfeature__title">Nature's Finest</h4>-->
            <!--                        <p>100% Natural Goodness, Straight to You!</p>-->
            <!--                    </div>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="col">-->
            <!--                <div class="mainfeature__item text-center mb-30">-->
            <!--                    <div class="mainfeature__icon">-->
            <!--                        <img src="{{ asset('asset/img/icon/choose-icon4.svg') }}" alt="">-->
            <!--                    </div>-->
            <!--                    <div class="mainfeature__content">-->
            <!--                        <h4 class="mainfeature__title">100% Organic Goods</h4>-->
            <!--                        <p>Striving to improve efficiency at all levels</p>-->
            <!--                    </div>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="col">-->
            <!--                <div class="mainfeature__item text-center mb-30">-->
            <!--                    <div class="mainfeature__icon">-->
            <!--                        <img src="{{ asset('asset/img/icon/about-svg2.svg') }}" alt="">-->
            <!--                    </div>-->
            <!--                    <div class="mainfeature__content">-->
            <!--                        <h4 class="mainfeature__title">Eco Friendly</h4>-->
            <!--                        <p>Bringing products that stand apart from the rest to the country's people</p>-->
            <!--                    </div>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
        </section>
        <!-- feature-area-end -->
    </main>
<!-- footer-area-start -->
<footer>
    <div class="tpfooter__area theme-bg-2">
        <div class="tpfooter__top pb-15">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="tpfooter__widget footer-col-1 mb-50">
                            <h4 class="tpfooter__widget-title">Let Us Help You</h4>
                            <p class="mb-3">If you have any question, please <br> contact us at:  </p>
                            <h4 class="tpfooter__widget-title" style="margin-bottom: 10px; margin-top: 10px;">Call us</h4>
                            <p><a href="tel:011-41068958">011-41068958</a> </p>
                            <p><a href="tel:+91-9911099001">+91-9911099001</a></p>
                            <h4 class="tpfooter__widget-title" style="margin-bottom: 10px; margin-top: 10px;">Mail Us</h4>
                            <p><a href="mailto:bahetyoverseas@gmail.com">bahetyoverseas@gmail.com</a> </p>
                            <p><a href="mailto:boploffice@gmail.com">boploffice@gmail.com</a></p>
                            <div class="tpfooter__widget-social mt-20">
                                <span class="tpfooter__widget-social-title mb-5">Social Media:</span>
                                <a href="https://www.facebook.com/bahetyoverseas/" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <a href="https://www.instagram.com/bahetyoverseas/" target="_blank"><i class="fab fa-instagram"></i></a>
                                <!--<a href="#"><i class="fab fa-twitter"></i></a>-->
                                <!--<a href="#"><i class="fab fa-youtube"></i></a>-->
                                <!--<a href="#"><i class="fab fa-pinterest-p"></i></a>-->
                                <!--<a href="#"><i class="fab fa-skype"></i></a>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <div class="tpfooter__widget footer-col-2 mb-50">
                            <h4 class="tpfooter__widget-title">Office No</h4>
                            <p>DPT 611, DLF Prime Towers <br> Plot No. F79  & 80, <br> Okhla Phase 1, <br>South Delhi, Delhi, India - 110020</p>
                            <div class="tpfooter__widget-time-info mt-35">
                                <span>Monday – Saturday: <b> <br> 10:00 AM – 9:00 PM</b></span>
                                <!--<span>Saturday: <b>10:10 AM – 06:10 PM</b></span>-->
                                <!--<span>Sunday: <b>Close</b></span>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-4 col-md-4 col-sm-5">
                        <div class="tpfooter__widget footer-col-3 mb-50">
                            <h4 class="tpfooter__widget-title">TOP PRODUCTS</h4>
                            <div class="tpfooter__widget-links">
                                <ul>
                                    <li><a href="{{ route('about') }}">About Us</a></li>
                                    <li><a href="{{ route('dealer') }}">Dealer Enquiry</a></li>
                                    <li><a href="{{ route('contact') }}">Contact Us</a></li>
                                    <li><a href="{{ route('term') }}">Terms of Use</a></li>
                                    <li><a href="{{ route('return') }}">Return Policy</a></li>
                                    <li><a href="{{ route('privacy') }}">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-8 col-sm-7">
                        <div class="tpfooter__widget footer-col-4 mb-50">
                            <h4 class="tpfooter__widget-title">Our newsletter</h4>
                            <div class="tpfooter__widget-newsletter">
                                <p>Subscribe to the Bahety Overseas mailing list to receive updates on new arrivals & other information.</p>
                                <form action="#">
                                    <span><i><img src="asset/img/shape/message-1.svg" alt=""></i></span>
                                    <input type="email" placeholder="Your email address...">
                                    <button class="tpfooter__widget-newsletter-submit tp-news-btn">Subscribe</button>
                                </form>
                                <div class="tpfooter__widget-newsletter-check mt-30">
                                    <p>
                                        <span class="tpfooter__copyright-text">Copyright © <a href="https://bahetyoverseas.in/">Bahety Overseas</a> all rights reserved.</span><br>
                                        <span class="tpfooter__copyright-text mt-10">Design & Development by <a href="#">Dhanda Digital Marketers</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer-area-end -->
<!-- JS here -->
<script src="{{ asset('asset/js/jquery.js') }}"></script>
<script src="{{ asset('asset/js/waypoints.js') }}"></script>
<script src="{{ asset('asset/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('asset/js/swiper-bundle.js') }}"></script>
<script src="{{ asset('asset/js/nice-select.js') }}"></script>
<script src="{{ asset('asset/js/slick.js') }}"></script>
<script src="{{ asset('asset/js/magnific-popup.js') }}"></script>
<script src="{{ asset('asset/js/counterup.js') }}"></script>
<script src="{{ asset('asset/js/wow.js') }}"></script>
<script src="{{ asset('asset/js/isotope-pkgd.js') }}"></script>
<script src="{{ asset('asset/js/imagesloaded-pkgd.js') }}"></script>
<script src="{{ asset('asset/js/countdown.js') }}"></script>
<script src="{{ asset('asset/js/ajax-form.js') }}"></script>
<script src="{{ asset('asset/js/meanmenu.js') }}"></script>
<script src="{{ asset('asset/js/main.js') }}"></script>
@yield('custom-javascript')
</body>
</html>