@extends('front.layout.app')
@section('title', $category->metatitle)
@section('meta-keyword', $category->metakeyword)
@section('meta-desc', $category->metadescription)
@section('content')
    <style>
        .basic-pagination ul li a:hover,
        .basic-pagination ul li a.current,
        .basic-pagination ul li span:hover,
        .basic-pagination ul li.active {
            background: var(--tp-heading-secondary);
            border-color: var(--tp-heading-secondary);
            color: #fff;
            border-radius: 25px;
        }

        /* ul li */
        ul.list {
            margin: 0;
            padding: 0;
            list-style: none;
        }

        ul.list li {
            display: flex;
            padding: 15px;
            flex-direction: column;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 10px;
            background-color: #fff;
            border-left: 4px solid #fff;
            transition: all 0.3s ease;
            position: relative;
            cursor: pointer;
            border-radius: 4px;
            overflow: hidden;
        }

        .product__filter-content {
            background-color: #fe0000;
            color: white;
            border-radius: 10px;
            padding: 12px 20px;
            font-size: 18px;
        }
        .subcategory-div{
         background: #f1f1f1; margin-top: 0px; margin-bottom: 20px; border-radius: 10px 10px 0 0; box-shadow: 0 0 9px 0 #cacaca;
        }
    </style>
    <!-- breadcrumb-area-start -->
    <div class="breadcrumb__area grey-bg pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tp-breadcrumb__content">
                        <div class="tp-breadcrumb__list">
                            <span class="tp-breadcrumb__active"><a href="{{ route('index') }}">Home</a></span>
                            <span class="dvdr">/</span>
                            <span>{{ $category->name }}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb-area-end -->
    <!-- shop-area-start -->
    <section class="shop-area-start grey-bg pb-200">
        <div class="container">
            <div class="row">
                @if (getCategories()->isNotEmpty())
                    <div class="col-xl-2 col-lg-12 col-md-12">
                        <div class="tpshop__leftbar">
                            <div class="tpshop__widget mb-30 pb-25">
                                <h4 class="tpshop__widget-title">Product Categories</h4>
                                <ul class="list">
                                    @foreach (getCategories() as $categorry)
                                        <li><a href="{{ route('product', $categorry->slug) }}">{{ $categorry->name }}</a>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                    </div>
                @endif
                <div class="col-xl-10 col-lg-12 col-md-12">
                    <div class="tpshop__top ml-60">
                        @if ($category->banner)
                            <div class="tpshop__banner mb-20"
                                data-background="{{ asset('uploads/category/' . $category->banner . '') }}">
                                <div class="tpshop__content text-center">
                                    <span>Bahety Overseas</span>
                                    <h4 class="tpshop__content-title mb-20">{{ $category->name }}</h4>
                                </div>
                            </div>
                        @else
                            <div class="tpshop__banner mb-20" style="background: #2cb7d6;">
                                <div class="tpshop__content text-center">
                                    <span>Bahety Overseas</span>
                                    <h4 class="tpshop__content-title mb-20">{{ $category->name }}</h4>
                                </div>
                            </div>
                        @endif


                        @if ($category->category_type == '2')
                           {{-- Subcategory --}}
                           @foreach ($products as $subcategoryName => $subcategoryProducts)
                              <div class="subcategory-div">
                                <div class="product__filter-content mb-30">
                                    <div class="row align-items-center">
                                        <div class="product__item-count text-center">
                                            <span>{{ $subcategoryName }}</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="row row-cols-xxl-3 row-cols-xl-3 row-cols-lg-3 row-cols-md-3 row-cols-sm-2 row-cols-1 tpproduct__shop-item p-3">
                                    @foreach ($subcategoryProducts as $product)
                                        <div class="col">
                                            <div class="tpproduct p-relative mb-20">
                                                <div class="tpproduct__thumb p-relative text-center">
                                                    <a href="{{ route('detail', $product->slug) }}"><img
                                                            src="{{ asset('uploads/product/' . $product->thumbnail . '') }}"
                                                            alt=""></a>
                                                    <a class="tpproduct__thumb-img"
                                                        href="{{ route('detail', $product->slug) }}"><img
                                                            src="{{ asset('uploads/product/' . $product->thumbnail . '') }}"
                                                            alt=""></a>
                                                </div>
                                                <div class="tpproduct__content">
                                                    <h4 class="tpproduct__title">
                                                        <a
                                                            href="{{ route('detail', $product->slug) }}">{{ $product->name }}</a>
                                                    </h4>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                              </div>
                           @endforeach
                           {{-- Subcategory --}}
                        @else
                           {{-- Category --}}
                           @if(count($products) > 0)   
                              <div class="row row-cols-xxl-3 row-cols-xl-3 row-cols-lg-3 row-cols-md-3 row-cols-sm-2 row-cols-1 tpproduct__shop-item">
                                 @foreach ($products as $product)
                                       <div class="col">
                                          <div class="tpproduct p-relative mb-20">
                                             <div class="tpproduct__thumb p-relative text-center">
                                                   <a href="{{ route('detail', $product->slug) }}"><img
                                                         src="{{ asset('uploads/product/' . $product->thumbnail . '') }}"
                                                         alt=""></a>
                                                   <a class="tpproduct__thumb-img"
                                                      href="{{ route('detail', $product->slug) }}"><img
                                                         src="{{ asset('uploads/product/' . $product->thumbnail . '') }}"
                                                         alt=""></a>
                                             </div>
                                             <div class="tpproduct__content">
                                                   <h4 class="tpproduct__title">
                                                      <a
                                                         href="{{ route('detail', $product->slug) }}">{{ $product->name }}</a>
                                                   </h4>
                                             </div>
                                          </div>
                                       </div>
                                 @endforeach
                              </div>
                              <!-- pagination -->
                              <div class="basic-pagination text-center mt-35">
                                 {{ $products->links('pagination::default') }}
                              </div>
                           @else
                              <p class="nodata-msg pt-30" >{{ $category->name }} <br> Product Coming Soon</p>
                           @endif
                            {{-- Category --}}
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- shop-area-end -->
@endsection
