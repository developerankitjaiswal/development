@extends('front.layout.app')
@section('title', 'Best Drinks & Beverage In Delhi')
@section('content')
        <!-- slider-area-start -->
        <section class="slider-area tpslider-delay">
            <div class="swiper-container slider-active">
                <div class="swiper-wrapper">
                    @foreach ($showbanner as $banner)
                        <div class="swiper-slide ">
                            <div class="tpslider pt-90 pb-0 grey-bg" data-background="{{asset('uploads/banner/'.$banner->image.'')}}"></div>
                        </div>
                    @endforeach
                </div>
                <div class="tpslider__arrow d-none  d-xxl-block">
                    <button class="tpsliderarrow tpslider__arrow-prv"><i class="icon-chevron-left"></i></button>
                    <button class="tpsliderarrow tpslider__arrow-nxt"><i class="icon-chevron-right"></i></button>
                </div>
                <div class="slider-pagination d-xxl-none"></div>
            </div>
        </section>
        <!-- slider-area-end -->



        <!-- product-area-start -->
        @if (count($products) > 0)
        <section class="product-area grey-bg pt-30">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="tpsection mb-35">
                            <h4 class="tpsection__sub-title">~ Bahety Overseas ~</h4>
                            <h4 class="tpsection__title">Beverage We Offer's</h4>
                            <p>Experience the exquisite explosion of flavors with our tantalizing beverage selection</p>
                        </div>
                    </div>
                </div>
                <div class="tpproduct__arrow p-relative">
                    <div class="swiper-container tpproduct-active tpslider-bottom p-relative">
                        <div class="swiper-wrapper">
                            @foreach ($products as $product)    
                                <div class="swiper-slide">
                                    <div class="tpproduct p-relative">
                                        <div class="tpproduct__thumb p-relative text-center">
                                            <a href="{{ route('detail', $product->slug) }}"><img src="{{asset('uploads/product/'.$product->thumbnail.'')}}" alt=""></a>
                                            <a class="tpproduct__thumb-img" href="{{ route('detail', $product->slug) }}"><img src="{{asset('uploads/product/'.$product->thumbnail.'')}}" alt=""></a>
                                        </div>
                                        <div class="tpproduct__content">
                                            <h4 class="tpproduct__title">
                                                <a href="{{ route('detail', $product->slug) }}">{{ $product->name }}</a>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                    @if (count($products) > 6)
                    <div class="tpproduct-btn">
                        <div class="tpprduct-arrow tpproduct-btn__prv"><a href="#"><i class="icon-chevron-left"></i></a></div>
                        <div class="tpprduct-arrow tpproduct-btn__nxt"><a href="#"><i class="icon-chevron-right"></i></a></div>
                    </div>
                    @endif
                </div>
            </div>
        </section>
        @endif
        <!-- product-area-end -->


        <!-- banner-area-start -->
        <section class="banner-area pt-60 grey-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="tpbanner__item mb-30">
                            <a href="#">
                                <div class="tpbanner__content" data-background="{{asset('uploads/cheese-ball.jpg')}}"></div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="tpbanner__item mb-30">
                            <a href="#">
                                <div class="tpbanner__content" data-background="{{asset('uploads/wine-bahety.jpg')}}"></div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="tpbanner__item mb-30">
                            <a href="#">
                                <div class="tpbanner__content" data-background="{{asset('uploads/noodles.jpg')}}"></div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- banner-area-end -->

        <!-- product-area-start -->
        <section class="weekly-product-area grey-bg pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="tpsection mb-20">
                            <h4 class="tpsection__sub-title">~ Bahety Overseas ~</h4>
                            <h4 class="tpsection__title">Our Top Categories</h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="tpnavtab__area pb-40">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <button class="nav-link active" id="nav-all-tab" data-bs-toggle="tab" data-bs-target="#nav-all" type="button" role="tab" aria-controls="nav-all" aria-selected="true">All Products</button>
                                    @foreach($navcategories as $navcategory)
                                        <button class="nav-link" id="nav-{{ $navcategory->id }}-tab" data-bs-toggle="tab" data-bs-target="#nav-{{ $navcategory->id }}" type="button" role="tab" aria-controls="nav-{{ $navcategory->id }}" aria-selected="false">{{ $navcategory->name }}</button>
                                    @endforeach
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-all" role="tabpanel" aria-labelledby="nav-all-tab" tabindex="0">
                                    <div class="tpproduct__arrow p-relative">
                                        <div class="swiper-container tpproduct-active tpslider-bottom p-relative">
                                            <div class="swiper-wrapper">
                                                @foreach ($navproducts as $product) 
                                                    <div class="swiper-slide">
                                                        <div class="tpproduct p-relative">
                                                            <div class="tpproduct__thumb p-relative text-center">
                                                                <a href="{{ route('detail', $product->slug) }}"><img src="{{asset('uploads/product/'.$product->thumbnail.'')}}" alt=""></a>
                                                                <a class="tpproduct__thumb-img" href="{{ route('detail', $product->slug) }}"><img src="{{asset('uploads/product/'.$product->thumbnail.'')}}" alt=""></a>
                                                            </div>
                                                            <div class="tpproduct__content">
                                                                <h4 class="tpproduct__title">
                                                                    <a href="{{ route('detail', $product->slug) }}">{{ $product->name }}</a>
                                                                </h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                        @if (count($navproducts) > 6)
                                        <div class="tpproduct-btn">
                                            <div class="tpprduct-arrow tpproduct-btn__prv"><a href="#"><i class="icon-chevron-left"></i></a></div>
                                            <div class="tpprduct-arrow tpproduct-btn__nxt"><a href="#"><i class="icon-chevron-right"></i></a></div>
                                        </div>
                                        @endif
                                    </div>
                                </div>
                                @foreach($navcategories as $navcategory)
                                    <div class="tab-pane fade" id="nav-{{ $navcategory->id }}" role="tabpanel" aria-labelledby="nav-{{ $navcategory->id }}-tab" tabindex="0">
                                        <div class="tpproduct__arrow p-relative">
                                            <div class="swiper-container tpproduct-active tpslider-bottom p-relative">
                                                <div class="swiper-wrapper">
                                                @foreach($navcategory->products as $pro)
                                                    <div class="swiper-slide">
                                                        <div class="tpproduct p-relative">
                                                            <div class="tpproduct__thumb p-relative text-center">
                                                                <a href="{{ route('detail', $pro->slug) }}"><img src="{{asset('uploads/product/'.$pro->thumbnail.'')}}" alt=""></a>
                                                                <a class="tpproduct__thumb-img" href="{{ route('detail', $pro->slug) }}"><img src="{{asset('uploads/product/'.$pro->thumbnail.'')}}" alt=""></a>
                                                            </div>
                                                            <div class="tpproduct__content">
                                                                <h4 class="tpproduct__title">
                                                                    <a href="{{ route('detail', $pro->slug) }}">{{ $pro->name }}</a>
                                                                </h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                                </div>
                                            </div>
                                            @if (count($navcategory->products) > 6)
                                            <div class="tpproduct-btn">
                                                <div class="tpprduct-arrow tpproduct-btn__prv"><a href="#"><i class="icon-chevron-left"></i></a></div>
                                                <div class="tpprduct-arrow tpproduct-btn__nxt"><a href="#"><i class="icon-chevron-right"></i></a></div>
                                            </div>
                                            @endif
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- product-area-end -->

         <!-- testimonial-area-start -->
         <section class="testimonial-area tptestimonial__bg pt-80 pb-55 p-relative">
            <div class="container">
                <div class="testimonial__shape p-relative d-none d-md-block">
                    <img src="asset/img/shape/tree-leaf-4.svg" alt="" class="testimonial__shape-one">
                    <img src="asset/img/shape/tree-leaf-5.svg" alt="" class="testimonial__shape-two">
                    <img src="asset/img/shape/tree-leaf-6.png" alt="" class="testimonial__shape-three">
                </div>
               <div class="row">
                  <div class="col-lg-12 text-center">
                     <div class="tpsection mb-35">
                        <h4 class="tpsection__sub-title">~ Happy Customer ~</h4>
                        <h4 class="tpsection__title">What Client Says</h4>
                        <p>Experience the beverage bliss that keeps our clients coming back!</p>
                     </div>
                  </div>
               </div>
               <div class="swiper-container tptestimonial-active3 p-relative">
                  <div class="swiper-wrapper">
                    @foreach($testimonials as $testimonial)
                    <div class="swiper-slide">
                        <div class="row justify-content-center p-relative">
                           <div class="col-md-12">
                                <div class="tptestimonial__item text-center mb-30">
                                        @if(!empty($testimonial->thumbnail))
                                            <div class="tptestimonial__avata mb-25">
                                                <img src="{{asset('uploads/testimonial/'.$testimonial->thumbnail.'')}}" alt="">
                                            </div>
                                        @endif
                                        <div class="tptestimonial__content tptestimonial__content2">
                                            <p>" {{ $testimonial->description }} " </p>
                                            <div class="tptestimonial__rating mb-5">
                                            <a href="#"><i class="icon-star_outline1"></i></a>
                                            <a href="#"><i class="icon-star_outline1"></i></a>
                                            <a href="#"><i class="icon-star_outline1"></i></a>
                                            <a href="#"><i class="icon-star_outline1"></i></a>
                                            <a href="#"><i class="icon-star_outline1"></i></a>
                                            </div>
                                            <h4 class="tptestimonial__title">{{ $testimonial->name }}</h4>
                                            <span class="tptestimonial__avata-position">{{ $testimonial->designation }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                  </div>
               </div>
            </div>
         </section>
         <!-- testimonial-area-end -->


        <!-- instagram-area-start -->
        <section class="instagram-area grey-bg pt-70 pb-80">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="tpsection mb-35">
                            <h4 class="tpsection__title">@bahetyoverseas</h4>
                            <p>Tag <a href="index.php">@bahetyoverseas</a> in your Instagram photos for a chance to be featured here. <br> Find more inspiration on our Instagram.</p>
                        </div>
                    </div>
                </div>
                <div class="swiper-container tpinsta-active">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="tpinsta__item p-relative fix">
                                <a href="#"><img src="asset/img/post-1.jpg" alt="thumb-img"></a>
                                <a class="tpinsta__links popup-image" href="asset/img/post-1.jpg"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div class="tpinsta__item p-relative fix">
                                <a href="#"><img src="asset/img/post-4.jpg" alt="thumb-img"></a>
                                <a class="tpinsta__links popup-image" href="asset/img/post-4.jpg"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="tpinsta__item p-relative fix">
                                <a href="#"><img src="asset/img/post-5.jpg" alt="thumb-img"></a>
                                <a class="tpinsta__links popup-image" href="asset/img/post-5.jpg"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="tpinsta__item p-relative fix">
                                <a href="#"><img src="asset/img/post-6.jpg" alt="thumb-img"></a>
                                <a class="tpinsta__links popup-image" href="asset/img/post-6.jpg"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="tpinsta__item p-relative fix">
                                <a href="#"><img src="asset/img/post-2.jpg" alt="thumb-img"></a>
                                <a class="tpinsta__links popup-image" href="asset/img/post-2.jpg"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="tpinsta__item p-relative fix">
                                <a href="#"><img src="asset/img/post-7.jpg" alt="thumb-img"></a>
                                <a class="tpinsta__links popup-image" href="asset/img/post-7.jpg"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="tpinsta__item p-relative fix">
                                <a href="#"><img src="asset/img/post-8.jpg" alt="thumb-img"></a>
                                <a class="tpinsta__links popup-image" href="asset/img/post-8.jpg"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="tpinsta__item p-relative fix">
                                <a href="#"><img src="asset/img/post-3.jpg" alt="thumb-img"></a>
                                <a class="tpinsta__links popup-image" href="asset/img/post-3.jpg"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- instagram-area-end -->
@endsection
@section('custom-javascript')
<script>
    
</script>
@endsection