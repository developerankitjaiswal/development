@extends('admin.layout.app')
@section('title', 'Welcome To Dashboard')
@section('content')
    <div id="content" class="app-content">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h1 class="page-header">Dashboard</h1>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">
                    <ol class="breadcrumb float-xl-end">
                        <li class="breadcrumb-item"><a href="javascript:;">Home</a></li>
                        <li class="breadcrumb-item active">Welcome To Dashboard</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <a href="#">
                    <div class="card">
                        <div class="card-body no-padding" style="height:208px">
                            <div class="alert alert-callout alert-info no-margin">
                                <strong class="text-xl" style="font-size: 50px;">0 </strong><br>
                                <span class="opacity-90">Enquiry List</span>
                                <!-- <h1 class="pull-right text-info" style="margin-top: -20px;"><img src="assets/img/icon.png" width="100px"></h1> -->
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-lg-6">
                        <a href="{{ route('product.index') }}">
                            <div class="card">
                                <div class="card-body no-padding">
                                    <div class="alert alert-callout alert-danger no-margin">
                                        <strong class="text-xl">{{ $totalProductCount }}</strong><br />
                                        <span class="opacity-50">Total Product</span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-6">
                        <a href="{{ route('category.index') }}">
                            <div class="card">
                                <div class="card-body no-padding">
                                    <div class="alert alert-callout alert-warning no-margin">
                                        <strong class="text-xl">{{ $totalCategoryCount }}</strong><br />
                                        <span class="opacity-50">Total Category</span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-6">
                        <a href="{{ route('testimonial.index') }}">
                            <div class="card">
                                <div class="card-body no-padding">
                                    <div class="alert alert-callout alert-success no-margin">
                                        <!-- <h1 class="pull-right text-success"><img src="assets/img/icon.png" width="50px;"></h1> -->
                                        <strong class="text-xl">{{ $totalTestimonialCount }}</strong><br />
                                        <span class="opacity-50">Total Testimonial</span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    <div class="col-lg-6">
                        <a href="{{ route('blog.index') }}">
                            <div class="card">
                                <div class="card-body no-padding">
                                    <div class="alert alert-callout alert-danger no-margin">
                                        <!-- <h1 class="pull-right text-danger"><img src="assets/img/icon.png" width="50px;"></h1> -->
                                        <strong class="text-xl">{{ $totalBlogCount }}</strong><br />
                                        <span class="opacity-50">Total Blogs</span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    
                </div>
            </div>
        </div>
    </div>
@endsection
