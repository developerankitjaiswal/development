@extends('admin.layout.app')
@section('title', 'Create Testimonial')
@section('content')
    <div id="content" class="app-content">
        <div class="d-flex align-items-center mb-3">
            <div>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                    <li class="breadcrumb-item active"><i class="fa fa-arrow-back"></i> Testimonial Manageemnt</li>
                </ol>
                <h1 class="page-header mb-0">Update Testimonial</h1>
            </div>
            <div class="ms-auto">
                <a href="{{ route('testimonial.index') }}" class="btn btn-primary rounded-0 px-4"><i
                        class="fa fa-list fa-lg me-2 ms-n2 text-success-900"></i>MANAGE TESTIMONIAL</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <form action="{{ route('testimonial.update', $testimonial->id) }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="card border-0 mb-4">
                        <div class="card-header h6 mb-0 bg-none p-3">
                            <i class="fa fa-list fa-lg fa-fw text-dark text-opacity-50 me-1"></i>Update Testimonial
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <div class="mb-3">
                                        <label class="form-label" for="name">Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="name" id="name"
                                            placeholder="Enter Name" value="{{ $testimonial->name }}">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="mb-3">
                                        <label class="form-label" for="name">Designation<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="designation" id="designation"
                                            placeholder="Enter Designation" value="{{ $testimonial->designation }}">
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="mb-3">
                                        <label class="form-label" for="slug">Testimonial Detail<span class="text-danger">*</span></label>
                                        <textarea name="description" id="description" class="form-control" rows="6">{{ $testimonial->description }}</textarea>
                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="mb-3">
                                        <label class="form-label" for="image">Thumbnail <span class="form-text">(optional)</span></label>
                                        <input type="file" class="form-control" name="thumbnail" id="image">
                                    </div>
                                    @if(!empty($testimonial->thumbnail))
                                        <div style="margin: 5px;"> 
                                            <img src="{{ asset('uploads/testimonial/'.$testimonial->thumbnail.'') }}" class="rounded h-100px my-n1 mx-n1"/> 
                                        </div>
                                    @endif
                                </div>

                                <div class="col-3">
                                    <div class="mb-3">
                                        <label class="form-label" for="status">Status<span class="text-danger">*</span></label>
                                        <select class="form-select" name="status" id="status">
                                            <option value="1" {{ ($testimonial->status == 1) ? 'selected' : '' }}>Active</option>
                                            <option value="0" {{ ($testimonial->status == 0) ? 'selected' : '' }}>Inactive</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="mb-3">
                                        <label class="form-label" for="sort">Display Order <span class="form-text">(optional)</span></label>
                                        <input type="number" class="form-control" name="sort" id="sort"
                                            placeholder="Enter Display Order" value="{{ $testimonial->display_order }}">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card-footer bg-none d-flex p-3">
                            <button type="submit" name="saveblog" class="btn btn-primary"><i class="fas fa-check"></i>
                                CLICK TO CREATE TESTIMONIAL </button>
                            <a href="#" class="btn btn-danger ms-2">CANCEL</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
