<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>@yield('title') | Adminpanel</title>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('assets/img/favicon.png') }}">
    <link href="{{ asset('assets/css/fontawesome.css') }}" rel="stylesheet" />
    <link href="{{ asset('assets/css/vendor.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('assets/css/default/app.min.css') }}" rel="stylesheet" />
    <!----Table---->
    <link href="{{ asset('assets/plugins/datatables.net-bs5/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('assets/plugins/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css') }}"
        rel="stylesheet" />
    <!----Table---->
    <link href="{{ asset('assets/css/custom.css') }}" rel="stylesheet" />
    <link href="{{ asset('assets/css/toaster.css')}}" rel="stylesheet" />
</head>
<!----Head----->
<body class="theme-blue">
    <div id="app" class="app app-header-fixed app-sidebar-fixed app-gradient-enabled">
        <div id="header" class="app-header">
            <div class="navbar-header"> <a href="{{ route('admin.dashboard') }}" class="navbar-brand"><img
                        src="{{ asset('assets/img/logo.png') }}"></a>
                <button type="button" class="navbar-mobile-toggler" data-toggle="app-sidebar-mobile"> <span
                        class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            </div>
            <div class="navbar-nav">
                <div class="navbar-item dropdown"> <a href="#" data-bs-toggle="dropdown"
                        class="navbar-link dropdown-toggle icon"> <i class="fa fa-info-circle"></i>  </a>
                    <div class="dropdown-menu media-list dropdown-menu-end">
                        <div class="dropdown-header">CUSTOMER SUPPORT</div>
                        <a href="javascript:;" class="dropdown-item media">
              <div class="media-left"> <img src="{{asset('assets/img/abhishek.jpg')}}" class="media-object" alt="Abhishek" /> </div>
              <div class="media-body">
                <h6 class="media-heading">Abhishek Jaiswal </h6>
                <div class="text-muted fs-10px"><i class="fa fa-phone"></i> +91-880 024 5633</div>
                <div class="text-muted fs-10px"><i class="fa fa-envelope"></i> info@webcareindia.com</div>
                <div class="text-muted fs-10px"><i class="fab fa-whatsapp"></i> +91-880 024 5633</div>
              </div>
            </a> <a href="javascript:;" class="dropdown-item media">
              <div class="media-left"> <img src="{{asset('assets/img/anil.jpg')}}" class="media-object" alt="Anil" />  </div>
              <div class="media-body">
                <h6 class="media-heading">Anil Maurya</h6>
                <div class="text-muted fs-10px"><i class="fa fa-phone"></i> +91- 920 509 8526</div>
                <div class="text-muted fs-10px"><i class="fa fa-envelope"></i> webcaresindia@gmail.com</div>
                <div class="text-muted fs-10px"><i class="fab fa-whatsapp"></i> +91-880 024 5633</div>
              </div> </a>
                    </div>
                </div>
                <div class="navbar-item navbar-user dropdown"> <a href="#"
                        class="navbar-link dropdown-toggle d-flex align-items-center" data-bs-toggle="dropdown"> <img
                            src="{{ asset('assets/img/user.png') }}" /> <span> <span
                                class="d-none d-md-inline">{{ Auth::guard('admin')->user()->name }}</span> <b
                                class="caret"></b> </span> </a>
                    <div class="dropdown-menu dropdown-menu-end me-1">
                        <!--<a href="#" class="dropdown-item">Edit Profile</a>-->
                        <!--<a href="#" class="dropdown-item">Change Password</a>-->
                        <!--<a href="#" class="dropdown-item">Setting</a>-->
                        <!--<div class="dropdown-divider"></div>-->
                        <a href="{{ route('admin.logout') }}" class="dropdown-item">Log Out</a>
                    </div>
                </div>
            </div>
        </div>
