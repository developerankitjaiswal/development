@extends('admin.layout.app')
@section('title', 'Create Blog')
@section('content')
    <div id="content" class="app-content">
        <div class="d-flex align-items-center mb-3">
            <div>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                    <li class="breadcrumb-item active"><i class="fa fa-arrow-back"></i> Blog Manageemnt</li>
                </ol>
                <h1 class="page-header mb-0">Create Blog</h1>
            </div>
        </div>
        <form action="{{ route('blog.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="col-lg-8">
                    <div class="card border-0 mb-4">
                        <div class="card-header h6 mb-0 bg-none p-3">
                            <i class="fa fa-dolly fa-lg fa-fw text-dark text-opacity-50 me-1"></i> Blog Information
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Blog Name<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Blog name" value="{{ old('name') }}">
                            </div>
                            
                            <div class="row">
                                <div class="col-8">
                                    <div class="mb-3">
                                        <label class="form-label">Blog Slug<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="slug" name="slug" placeholder="Blog Slug" readonly value="{{ old('slug') }}">
                                    </div>
                                </div>
                                
                                <div class="col-4">
                                    <div class="mb-3">
                                        <label class="form-label">Thumbnail Image<span class="text-danger">*</span></label>
                                        <input type="file" class="form-control" name="thumbnail">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 mb-4">
                        <div class="card-header h6 mb-0 bg-none p-3">
                            <i class="fa fa-dolly fa-lg fa-fw text-dark text-opacity-50 me-1"></i> Blog Description
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Description <span class="form-text">(optional)</span></label>
                                <div class="form-control p-0 overflow-hidden">
                                    <textarea class="textarea form-control" id="description" name="description" placeholder="Enter text ...">{{ old('description') }}</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-footer bg-none d-flex p-3">
                        <button type="submit" name="saveproduct" class="btn btn-primary"><i class="fas fa-check"></i>
                            CLICK TO CREATE BLOG </button>
                        <button type="reset" class="btn btn-danger ms-2">RESET</button>
                    </div>
                    
                </div>
        
                <div class="col-lg-4">
                    <div class="card border-0 mb-4">
                        <div class="card-header h6 mb-0 bg-none p-3 d-flex">
                            <div class="flex-1">
                                <div>Blog Status</div>
                            </div>
                        </div>
                        <div class="card-body fw-bold">
                            <div class="mb-3">
                                <label class="form-label" for="status">Blog Status<span class="text-danger">*</span></label>
                                <select class="form-select" name="status" id="status">
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Display Order <span class="form-text">(optional)</span></label>
                                <input type="number" class="form-control" name="sort" placeholder="Enter Display Order" value="{{ old('sort') }}">
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 mb-4">
                        <div class="card-header h6 mb-0 bg-none p-3 d-flex">
                            <div class="flex-1">
                                <div> Seo Content</div>
                            </div>
                        </div>
                        <div class="card-body fw-bold">
                            <div class="mb-3">
                                <label class="form-label">Meta Title <span class="form-text">(optional)</span></label>
                                <div class="form-control p-0 overflow-hidden">
                                    <textarea class="textarea form-control" name="metatitle" placeholder="Enter Meta Title...." rows="2">{{ old('metatitle') }}</textarea>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Meta Keyword <span class="form-text">(optional)</span></label>
                                <div class="form-control p-0 overflow-hidden">
                                    <textarea class="textarea form-control" name="metakeyword" placeholder="Enter Meta Keyword...." rows="2">{{ old('metakeyword') }}</textarea>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Meta Description <span class="form-text">(optional)</span></label>
                                <div class="form-control p-0 overflow-hidden">
                                    <textarea class="textarea form-control" name="metadescription" placeholder="Enter Meta Description ..." rows="4">{{ old('metadescription') }}</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
@endsection
@section('custom-javascript')
<script>
    $(document).ready(function() {
      $('#name').on('input', function() {
        var name = $(this).val().trim().toLowerCase();
        var slug = name.replace(/\s+/g, '-');   
        $('#slug').val(slug);
      });
    });
    //description
    ClassicEditor.create( document.querySelector( '#description'),{
        ckfinder:{
        uploadUrl: '{{ route('ckeditor.upload').'?_token='.csrf_token()}}'
        }
    } )
    .then( editor => {
        console.error( editor );
    } )
    .catch( error => {
        console.error( error );
    } );
</script>
@endsection
