@extends('admin.layout.app')
@section('title', 'Create Products')
@section('content')
    <div id="content" class="app-content">
        <div class="d-flex align-items-center mb-3">
            <div>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                    <li class="breadcrumb-item active"><i class="fa fa-arrow-back"></i> Product Manageemnt</li>
                </ol>
                <h1 class="page-header mb-0">Create Product</h1>
            </div>
        </div>
        <form action="{{ route('product.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="col-lg-8">
                    <div class="card border-0 mb-4">
                        <div class="card-header h6 mb-0 bg-none p-3">
                            <i class="fa fa-dolly fa-lg fa-fw text-dark text-opacity-50 me-1"></i> Product Information
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-8">
                                    <div class="mb-3">
                                        <label class="form-label">Product Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Product name" value="{{ old('name') }}">
                                    </div>
                                </div>
                            
                                <div class="col-4">
                                    <div class="mb-3">
                                        <label class="form-label" for="status">Product Category<span class="text-danger">*</span></label>
                                        <select class="form-select" name="category" id="category">
                                            <option value="">Select Product Category</option>
                                            @foreach ($categories as $category)
                                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            
                                <div class="col-8">
                                    <div class="mb-3">
                                        <label class="form-label">Product Slug<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="slug" name="slug" placeholder="Product Slug" readonly value="{{ old('slug') }}">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="mb-3">
                                        <label class="form-label">Select Sub Category <span class="form-text">(optional)</span></label>
                                        <select name="subcategory" id="subcategory" class="subcategory-select form-control">
                                            <option value="">Select Category First</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="mb-3">
                                        <label class="form-label">Thumbnail Image<span class="text-danger">*</span></label>
                                        <input type="file" class="form-control" name="thumbnail">
                                    </div>
                                </div>
                                <div class="col-6">    
                                    <div class="mb-3">
                                        <label class="form-label">Multiple Images <span class="form-text">(optional)</span></label>
                                        <input type="file" class="form-control" name="multimage">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 mb-4">
                        <div class="card-header h6 mb-0 bg-none p-3">
                            <i class="fa fa-dolly fa-lg fa-fw text-dark text-opacity-50 me-1"></i> Product Description
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Short Description<span class="text-danger">*</span></label>
                                <div class="form-control p-0 overflow-hidden">
                                    <textarea class="textarea form-control" id="shortdescription" name="shortdescription" placeholder="Enter text ...">{{ old('shortdescription') }}</textarea>
                                </div>
                            </div>
                            <div>
                                <label class="form-label">Description <span class="form-text">(optional)</span></label>
                                <div class="form-control p-0 overflow-hidden">
                                    <textarea class="textarea form-control" id="description" name="description" placeholder="Enter text ...">{{ old('description') }}</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-footer bg-none d-flex p-3">
                        <button type="submit" name="saveproduct" class="btn btn-primary"><i class="fas fa-check"></i>
                            CLICK TO CREATE PRODUCT </button>
                        <button type="reset" class="btn btn-danger ms-2">RESET</button>
                    </div>
                    
                </div>
        
                <div class="col-lg-4">
                    <div class="card border-0 mb-4">
                        <div class="card-header h6 mb-0 bg-none p-3 d-flex">
                            <div class="flex-1">
                                <div>Product Status</div>
                            </div>
                        </div>
                        <div class="card-body fw-bold">
                            <div class="mb-3">
                                <label class="form-label" for="status">Product Status<span class="text-danger">*</span></label>
                                <select class="form-select" name="status" id="status">
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Display Order <span class="form-text">(optional)</span></label>
                                <input type="number" class="form-control" name="sort" placeholder="Enter Display Order" value="{{ old('sort') }}">
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 mb-4">
                        <div class="card-header h6 mb-0 bg-none p-3 d-flex">
                            <div class="flex-1">
                                <div> Seo Content</div>
                            </div>
                        </div>
                        <div class="card-body fw-bold">
                            <div class="mb-3">
                                <label class="form-label">Meta Title <span class="form-text">(optional)</span></label>
                                <div class="form-control p-0 overflow-hidden">
                                    <textarea class="textarea form-control" name="metatitle" placeholder="Enter Meta Title...." rows="2">{{ old('metatitle') }}</textarea>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Meta Keyword <span class="form-text">(optional)</span></label>
                                <div class="form-control p-0 overflow-hidden">
                                    <textarea class="textarea form-control" name="metakeyword" placeholder="Enter Meta Keyword...." rows="2">{{ old('metakeyword') }}</textarea>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Meta Description <span class="form-text">(optional)</span></label>
                                <div class="form-control p-0 overflow-hidden">
                                    <textarea class="textarea form-control" name="metadescription" placeholder="Enter Meta Description ..." rows="4">{{ old('metadescription') }}</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
@endsection
@section('custom-javascript')
<script>
    $(document).ready(function() {
      $('#name').on('input', function() {
        var name = $(this).val().trim().toLowerCase();
        var slug = name.replace(/\s+/g, '-');   
        $('#slug').val(slug);
      });
    });
    //subcategory
    $(document).on("change","#category",function() {
        let categoryId = $(this).val();
        $.ajax({
            type: "GET",
            url: '{{ route('products.getsubcategory') }}',
            data: {'category_id': categoryId},
            dataType: "json",
            success: function (response) {
                $('#subcategory').find('option').not(":first").remove();
                $.each(response["subcategories"],function(key, item){
                    $('#subcategory').append(`<option value="${item.id}"> ${item.name} </option>`)
                });
            }
        });
    });
    //ckeditor
    ClassicEditor.create( document.querySelector( '#shortdescription'),{
        ckfinder:{
        uploadUrl: '{{ route('ckeditor.upload').'?_token='.csrf_token()}}'
        }
    } )
    //description
    ClassicEditor.create( document.querySelector( '#description'),{
        ckfinder:{
        uploadUrl: '{{ route('ckeditor.upload').'?_token='.csrf_token()}}'
        }
    } )
    .then( editor => {
        console.error( editor );
    } )
    .catch( error => {
        console.error( error );
    } );
</script>
@endsection
