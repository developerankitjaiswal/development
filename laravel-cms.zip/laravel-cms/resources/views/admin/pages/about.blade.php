@extends('admin.layout.app')
@section('title','Manage About Us')
@section('content')
<div id="content" class="app-content">
    <div class="d-flex align-items-center mb-3">
        <div>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active"><i class="fa fa-arrow-back"></i> About Manageemnt</li>
            </ol>
            <h1 class="page-header mb-0">About</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card border-0 mb-4">
                <div class="card-header h6 mb-0 bg-none p-3">
                    <i class="fa fa-question fa-lg fa-fw text-dark text-opacity-50 me-1"></i> Add About
                </div>
                <form action="{{ route('about.add') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="card-body">

                    <div class="row">
                        @if(!empty($pagedata->image))
                            <div class="col-9">
                        @else 
                            <div class="col-12">
                        @endif
                            <div class="mb-3">
                                <label class="form-label">Title</label>
                                <input type="text" class="form-control" name="title" placeholder="Enter Title " value="{{ !empty($pagedata->title) ? $pagedata->title : old('title') }}">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Subtitle</label>
                                <input type="text" class="form-control" name="subtitle" placeholder="Enter Subtitle" value="{{ !empty($pagedata->subtitle) ? $pagedata->subtitle : old('subtitle') }}">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Thumbnail</label>
                                <input type="file" class="form-control" name="fileimg">
                            </div>
                        </div>
                        @if(!empty($pagedata->image))
                            <div class="col-3">
                                <img src="{{asset('uploads/other/'.$pagedata->image)}}" width="200px" alt="About Image">
                            </div>
                        @endif
                    </div>

                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <div class="form-control p-0 overflow-hidden">
                                <textarea class="form-control" name="description" id="editor" placeholder="Enter text ..." rows="12">{{ !empty($pagedata->description) ? $pagedata->description : old('description') }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer bg-none d-flex p-3">
                        <button type="submit" name="saveblog" class="btn btn-primary"><i class="fas fa-check"></i> CLICK TO SAVE DETAIL </button>
                        <a href="#" class="btn btn-danger ms-2">CANCEL</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
@section('custom-javascript')
    <script>
        ClassicEditor
            .create(document.querySelector('#editor'), {
                ckfinder: {
                    uploadUrl: '{{ route('ckeditor.upload').' ? _token = '.csrf_token()}}'
                }
            })
            .then(editor => {
                console.error(editor);
            })
            .catch(error => {
                console.error(error);
            });
    </script>
@endsection