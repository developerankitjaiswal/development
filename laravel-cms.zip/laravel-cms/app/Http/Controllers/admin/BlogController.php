<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\Blog;
use Illuminate\Support\Str;

class BlogController extends Controller
{
    public function index()
    {
        $blogs = Blog::latest()->get();
        return view('admin.blog.view',compact('blogs'));
    }
    //create
    public function create()
    {
        return view('admin.blog.create');
    }
    //create category
    public function store_blog(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'slug' => 'required|unique:tbl_blogs',
            'thumbnail' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
            'description' => 'required',
            'status' => 'required',
        ]);
        if ($validator->passes()){
            $blog = new Blog;
            $thumbImage = 'blog_'.time().'.'.$request->thumbnail->extension();  
            $request->thumbnail->move(public_path('uploads/blog'), $thumbImage);
            $blog->name = $request->name;
            $blog->slug = Str::slug($request->slug);
            $blog->thumbnail = $thumbImage;
            $blog->description = $request->description;
            $blog->status = $request->status;
            $blog->display_order = $request->sort;
            $blog->metatitle = $request->metatitle;
            $blog->metakeyword = $request->metakeyword;
            $blog->metadescription = $request->metadescription;
            $blog->save();
            return redirect()->route('blog.create')->with('success','Blog has been created successfully.');
        } else {
            return redirect()->route('blog.create')->withErrors($validator);
        }
    }
    //edit
    public function edit_blog($blogID, Request $request )
    {
        $blog = Blog::find($blogID);
        if(empty($blog)){
            return redirect()->route('blog.index')->with('error', "Blog doesn't exist.");
        }
        return view('admin.blog.edit',compact('blog'));
    }
    //Update category
    public function update_blog($blogID, Request $request)
    {
        $blog = Blog::find($blogID);
        if(empty($blog)){
            return redirect()->route('blog.index')->with('error', "Blog doesn't exist.");
        }
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'slug' => 'required|unique:tbl_blogs,slug,'.$blog->id.',id',
            'description' => 'required',
            'status' => 'required',
        ]);
        if ($validator->passes()){
            /* for image*/
            if($request->hasFile('thumbnail')){
                $request->validate([
                    'thumbnail' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $thumbImage = 'blog_'.time().'.'.$request->thumbnail->extension();  
                $request->thumbnail->move(public_path('uploads/blog'), $thumbImage);
                $blog->thumbnail = $thumbImage;
            }
             /* for image*/
            $blog->name = $request->name;
            $blog->slug = Str::slug($request->slug);
            $blog->description = $request->description;
            $blog->status = $request->status;
            $blog->display_order = $request->sort;
            $blog->metatitle = $request->metatitle;
            $blog->metakeyword = $request->metakeyword;
            $blog->metadescription = $request->metadescription;
            $blog->save();
            return redirect()->route('blog.index')->with('success','Blog has been updated successfully.');
        } else {
            return redirect()->route('blog.index')->withErrors($validator);
        }
    }
    //status
    public function status_blog(Request $request) {
        $blog = Blog::findOrFail($request->blog_id);
        $blog->status = $request->status;
        $blog->save();
        return response()->json(['message' => 'Blog status updated successfully.']);
    }
    //delete
    public function delete_blog($product){
        $blogitem = Blog::find($product);
        if(empty($blogitem)){
            return redirect()->route('blog.index')->with('error', "Blog doesn't exist.");
        }
        if(!empty($blogitem->thumbnail)){
            if (file_exists(public_path('uploads/blog/' . $blogitem->thumbnail))) {
                unlink(public_path('uploads/blog/' . $blogitem->thumbnail));
            }
        }
        $blogitem->delete();
        return redirect()->route('blog.index')->with('success','Blog deleted successfully.');
    }
}
