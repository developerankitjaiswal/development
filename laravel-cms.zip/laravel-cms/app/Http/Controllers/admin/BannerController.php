<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\Banner;

class BannerController extends Controller
{
    public function index()
    {
        $banners = Banner::latest()->get();
        return view('admin.banner.view',compact('banners'));
    }
    //store
    public function store_create(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'btitle' => 'required|max:255',
            'bimage' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
            'bsort' => 'required',
            'bstatus' => 'required',
        ]);
        if ($validator->passes()){
            $imageName = 'banner_'.time().'.'.$request->bimage->extension();  
            $request->bimage->move(public_path('uploads/banner'), $imageName);
            $bann = new Banner;
            $bann->title = $request->btitle;
            $bann->subtitle = $request->bsubtitle;
            $bann->url_slug = $request->burl;
            $bann->display_order = $request->bsort;
            $bann->status = $request->bstatus;
            $bann->image = $imageName;
            $bann->save();
            return redirect()->route('banner.index')->with('success','Banner has been created successfully.');
        } else {
            return redirect()->route('banner.index')->withErrors($validator);
        }
    }
    //edit category
    public function edit_banner($bannerID, Request $request )
    {
        $bann = Banner::find($bannerID);
        if(empty($bann)){
            return redirect()->route('banner.index')->with('error', "Banner doesn't exist.");
        }
        return view('admin.banner.edit',compact('bann'));
    }
    //update category
    public function update_banner($bannerID, Request $request)
    {
        $banner = Banner::find($bannerID);
        if(empty($banner)){
            return redirect()->route('banner.index')->with('error', "Banner doesn't exist.");
        }
        $validator = Validator::make($request->all(),[
            'btitle' => 'required|max:255',
            'bsort' => 'required',
            'bstatus' => 'required',
        ]);
        if ($validator->passes()){
            /* for image*/
            if($request->hasFile('bimage')){
                $request->validate([
                    'bimage' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $imageName = 'banner_'.time().'.'.$request->bimage->extension();  
                $request->bimage->move(public_path('uploads/banner'), $imageName);
                $banner->image = $imageName;
            }
             /* for image*/
            $banner->title = $request->btitle;
            $banner->subtitle = $request->bsubtitle;
            $banner->url_slug = $request->burl;
            $banner->display_order = $request->bsort;
            $banner->status = $request->bstatus;
            $banner->save();
            return redirect()->route('banner.index')->with('success','Banner has been updated successfully.');
        } else {
            return redirect()->route('banner.index')->withErrors($validator);
        }
    }
    //status
    public function status_banner(Request $request) {
        $bann = Banner::findOrFail($request->banner_id);
        $bann->status = $request->status;
        $bann->save();
        return response()->json(['message' => 'Banner status updated successfully.']);
    }
    //delete
    public function delete_banner($banner){
        $banitem = Banner::find($banner);
        if(empty($banitem)){
            return redirect()->route('banner.index')->with('error', "Banner doesn't exist.");
        }
        if(!empty($banitem->image)){
            if (file_exists(public_path('uploads/banner/' . $banitem->image))) {
                unlink(public_path('uploads/banner/' . $banitem->image));
            }
        }
        $banitem->delete();
        return redirect()->route('banner.index')->with('success','Banner deleted successfully.');
    }
}
