<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\Support\Str;

class SubcategoryController extends Controller
{
    public function index()
    {
        $subcategories = Subcategory::select('tbl_subcategories.*', 'tbl_categories.name as categoryName')
                        ->leftJoin('tbl_categories', 'tbl_categories.id', '=', 'tbl_subcategories.category_id')
                        ->latest('tbl_subcategories.id')
                        ->get();
        return view('admin.subcategory.index',compact('subcategories'));
    }
    //create
    public function create()
    {
        $categories = Category::where('status', '=', 1)->orderBy('id', 'DESC')->get();
        return view('admin.subcategory.create',compact('categories'));
    }
    //create category
    public function store_create(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'slug' => 'required|unique:tbl_subcategories',
            'status' => 'required',
        ]);
        if ($validator->passes()){
            $subcat = new Subcategory;
            /* for image*/
            if($request->hasFile('thumbnail')){
                $request->validate([
                    'thumbnail' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $thumbImage = 'thumbnail_'.time().'.'.$request->thumbnail->extension();  
                $request->thumbnail->move(public_path('uploads/category'), $thumbImage);
                $subcat->thumbnail = $thumbImage;
            }
            if($request->hasFile('banner')){
                $request->validate([
                    'banner' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $bannerImage = 'banner_'.time().'.'.$request->banner->extension();  
                $request->banner->move(public_path('uploads/category'), $bannerImage);
                $subcat->banner = $bannerImage;
            }
             /* for image*/
            $subcat->category_id = $request->category; 
            $subcat->name = $request->name;
            $subcat->slug = Str::slug($request->slug);
            $subcat->display_order = $request->sort;
            $subcat->metatitle = $request->metatitle;
            $subcat->metakeyword = $request->metakeyword;
            $subcat->metadescription = $request->metadescription;
            $subcat->status = $request->status;
            $subcat->save();
            return redirect()->route('subcategory.index')->with('success','Sub Category has been created successfully.');
        } else {
            return redirect()->route('subcategory.create')->withErrors($validator);
        }
    }
    //edit category
    public function edit_category($categoryID, Request $request )
    {
        $subcategory = Subcategory::find($categoryID);
        if(empty($subcategory)){
            return redirect()->route('subcategory.index')->with('error', "Sub Category doesn't exist.");
        }
        $categories = Category::where('status', '=', 1)->orderBy('id', 'DESC')->get();
        return view('admin.subcategory.edit',compact('subcategory','categories'));
    }
    //update category
    public function update_category($subcategoryID, Request $request)
    {
        $subcat = Subcategory::find($subcategoryID);
        if(empty($subcat)){
            return redirect()->route('subcategory.index')->with('error', "Sub Category doesn't exist.");
        }
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'slug' => 'required|unique:tbl_subcategories,slug,'.$subcat->id.',id',
            'status' => 'required',
        ]);
        if ($validator->passes()){
            /* for image*/
            if($request->hasFile('thumbnail')){
                $request->validate([
                    'thumbnail' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $thumbImage = 'thumbnail_'.time().'.'.$request->thumbnail->extension();  
                $request->thumbnail->move(public_path('uploads/category'), $thumbImage);
                $subcat->thumbnail = $thumbImage;
            }
            if($request->hasFile('banner')){
                $request->validate([
                    'banner' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $bannerImage = 'banner_'.time().'.'.$request->banner->extension();  
                $request->banner->move(public_path('uploads/category'), $bannerImage);
                $subcat->banner = $bannerImage;
            }
             /* for image*/
            $subcat->category_id = $request->category;
            $subcat->name = $request->name;
            $subcat->slug = Str::slug($request->slug);
            $subcat->display_order = $request->sort;
            $subcat->metatitle = $request->metatitle;
            $subcat->metakeyword = $request->metakeyword;
            $subcat->metadescription = $request->metadescription;
            $subcat->status = $request->status;
            $subcat->save();
            return redirect()->route('subcategory.index')->with('success','Sub Category has been updated successfully.');
        } else {
            return redirect()->route('subcategory.create')->withErrors($validator);
        }
    }
    //status
    public function status_category(Request $request) {
        $subcategory = Subcategory::findOrFail($request->category_id);
        $subcategory->status = $request->status;
        $subcategory->save();
        return response()->json(['message' => 'Sub Category status updated successfully.']);
    }
    //delete
    public function delete_category($category){
        $subcat = Subcategory::find($category);
        if(empty($subcat)){
            return redirect()->route('subcategory.index')->with('error', "Sub Category doesn't exist.");
        }
        if(!empty($subcat->thumbnail)){
            if (file_exists(public_path('uploads/category/' . $subcat->thumbnail))) {
                unlink(public_path('uploads/category/' . $subcat->thumbnail));
            }
        }
        if(!empty($subcat->banner)){
            if (file_exists(public_path('uploads/category/' . $subcat->banner))) {
                unlink(public_path('uploads/category/' . $subcat->banner));
            }
        }
        $subcat->delete();
        return redirect()->route('subcategory.index')->with('success','Sub Category deleted successfully.');
    }
}
