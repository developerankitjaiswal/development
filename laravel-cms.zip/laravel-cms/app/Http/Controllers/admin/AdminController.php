<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Product;
use App\Models\Category;
use App\Models\Testimonial;
use App\Models\Blog;

class AdminController extends Controller
{
    //index
    public function index()
    {
        $totalProductCount = Product::count();
        $totalCategoryCount = Category::count();
        $totalTestimonialCount = Testimonial::count();
        $totalBlogCount = Blog::count();
        return view('admin.dashboard',compact('totalProductCount','totalCategoryCount','totalTestimonialCount','totalBlogCount'));
    }
    //do logout
    public function logout(){
        Auth::guard('admin')->logout();
        return redirect()->route('admin'); 
    }
    //ckeditor
    public function ckeditor_upload(Request $request)
    {
        if ($request->hasFile('upload')) {
            $originName = $request->file('upload')->getClientOriginalName();
            $fileName = pathinfo($originName, PATHINFO_FILENAME);
            $extension = $request->file('upload')->getClientOriginalExtension();
            $fileName = $fileName . '_' . time() . '.' . $extension;

            $request->file('upload')->move(public_path('uploads/other'), $fileName);
            $url = asset('uploads/other/' . $fileName);
            return response()->json(['fileName' => $fileName, 'uploaded' => 1, 'url' => $url]);
        }
    }
}
