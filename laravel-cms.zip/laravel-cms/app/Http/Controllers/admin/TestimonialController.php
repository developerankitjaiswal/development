<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\Testimonial;

class TestimonialController extends Controller
{
    public function index()
    {
        $testimonials = Testimonial::latest()->get();
        return view('admin.testimonial.view',compact('testimonials'));
    }
    //create
    public function create()
    {
        return view('admin.testimonial.create');
    }
    //create 
    public function store_testimonial(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'designation' => 'required',
            'status' => 'required',
            'description' => 'required',
        ]);
        if ($validator->passes()){
            $testi = new Testimonial;
            /* for image*/
            if($request->hasFile('thumbnail')){
                $request->validate([
                    'thumbnail' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $thumbImage = 'thumbnail_'.time().'.'.$request->thumbnail->extension();  
                $request->thumbnail->move(public_path('uploads/testimonial'), $thumbImage);
                $testi->thumbnail = $thumbImage;
            }
             /* for image*/
            $testi->name = $request->name;
            $testi->designation = $request->designation;
            $testi->display_order = $request->sort;
            $testi->description = $request->description;
            $testi->status = $request->status;
            $testi->save();
            return redirect()->route('testimonial.index')->with('success','Testimonial has been created successfully.');
        } else {
            return redirect()->route('testimonial.create')->withErrors($validator);
        }
    }
    //edit testimonial
    public function edit_testimonial($testimonialID, Request $request )
    {
        $testimonial = Testimonial::find($testimonialID);
        if(empty($testimonial)){
            return redirect()->route('testimonial.index')->with('error', "Testimonial doesn't exist.");
        }
        return view('admin.testimonial.edit',compact('testimonial'));
    }
    //update testimonial
    public function update_testimonial($testimonialID, Request $request)
    {
        $testimonial = Testimonial::find($testimonialID);
        if(empty($testimonial)){
            return redirect()->route('testimonial.index')->with('error', "Testimonial doesn't exist.");
        }
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'designation' => 'required',
            'status' => 'required',
            'description' => 'required',
        ]);
        if ($validator->passes()){
            /* for image*/
            if($request->hasFile('thumbnail')){
                $request->validate([
                    'thumbnail' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $thumbImage = 'thumbnail_'.time().'.'.$request->thumbnail->extension();  
                $request->thumbnail->move(public_path('uploads/testimonial'), $thumbImage);
                $testimonial->thumbnail = $thumbImage;
            }
             /* for image*/
             $testimonial->name = $request->name;
             $testimonial->designation = $request->designation;
             $testimonial->display_order = $request->sort;
             $testimonial->description = $request->description;
             $testimonial->status = $request->status;
             $testimonial->save();
            return redirect()->route('testimonial.index')->with('success','Testimonial has been updated successfully.');
        } else {
            return redirect()->route('testimonial.create')->withErrors($validator);
        }
    }
    //status
    public function status_testimonial(Request $request) {
        $testimonial = Testimonial::findOrFail($request->testimonial_id);
        $testimonial->status = $request->status;
        $testimonial->save();
        return response()->json(['message' => 'Testimonial status updated successfully.']);
    }
    //delete
    public function delete_testimonial($testimonial){
        $testimonial = Testimonial::find($testimonial);
        if(empty($testimonial)){
            return redirect()->route('testimonial.index')->with('error', "Testimonial doesn't exist.");
        }
        if(!empty($testimonial->thumbnail)){
            if (file_exists(public_path('uploads/testimonial/' . $testimonial->thumbnail))) {
                unlink(public_path('uploads/testimonial/' . $testimonial->thumbnail));
            }
        }
        $testimonial->delete();
        return redirect()->route('testimonial.index')->with('success','Testimonial deleted successfully.');
    }
}
