<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\Category;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::latest()->get();
        return view('admin.category.view',compact('categories'));
    }
    //create
    public function create()
    {
        return view('admin.category.create');
    }
    //create category
    public function store_create(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'slug' => 'required|unique:tbl_categories',
            'status' => 'required',
        ]);
        if ($validator->passes()){
            $catt = new Category;
            /* for image*/
            if($request->hasFile('thumbnail')){
                $request->validate([
                    'thumbnail' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $thumbImage = 'thumbnail_'.time().'.'.$request->thumbnail->extension();  
                $request->thumbnail->move(public_path('uploads/category'), $thumbImage);
                $catt->thumbnail = $thumbImage;
            }
            if($request->hasFile('banner')){
                $request->validate([
                    'banner' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $bannerImage = 'banner_'.time().'.'.$request->banner->extension();  
                $request->banner->move(public_path('uploads/category'), $bannerImage);
                $catt->banner = $bannerImage;
            }
             /* for image*/
            $catt->name = $request->name;
            $catt->slug = Str::slug($request->slug);
            $catt->category_type = $request->categorytype;
            $catt->display_order = $request->sort;
            $catt->metatitle = $request->metatitle;
            $catt->metakeyword = $request->metakeyword;
            $catt->metadescription = $request->metadescription;
            $catt->status = $request->status;
            $catt->save();
            return redirect()->route('category.index')->with('success','Category has been created successfully.');
        } else {
            return redirect()->route('category.create')->withErrors($validator);
        }
    }
    //edit category
    public function edit_category($categoryID, Request $request )
    {
        $category = Category::find($categoryID);
        if(empty($category)){
            return redirect()->route('category.index')->with('error', "Category doesn't exist.");
        }
        return view('admin.category.edit',compact('category'));
    }
    //update category
    public function update_category($categoryID, Request $request)
    {
        $category = Category::find($categoryID);
        if(empty($category)){
            return redirect()->route('category.index')->with('error', "Category doesn't exist.");
        }
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'slug' => 'required|unique:tbl_categories,slug,'.$category->id.',id',
            'status' => 'required',
        ]);
        if ($validator->passes()){
            /* for image*/
            if($request->hasFile('thumbnail')){
                $request->validate([
                    'thumbnail' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $thumbImage = 'thumbnail_'.time().'.'.$request->thumbnail->extension();  
                $request->thumbnail->move(public_path('uploads/category'), $thumbImage);
                $category->thumbnail = $thumbImage;
            }
            if($request->hasFile('banner')){
                $request->validate([
                    'banner' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $bannerImage = 'banner_'.time().'.'.$request->banner->extension();  
                $request->banner->move(public_path('uploads/category'), $bannerImage);
                $category->banner = $bannerImage;
            }
             /* for image*/
            $category->name = $request->name;
            $category->slug = Str::slug($request->slug);
            $category->category_type = $request->categorytype;
            $category->display_order = $request->sort;
            $category->metatitle = $request->metatitle;
            $category->metakeyword = $request->metakeyword;
            $category->metadescription = $request->metadescription;
            $category->status = $request->status;
            $category->save();
            return redirect()->route('category.index')->with('success','Category has been updated successfully.');
        } else {
            return redirect()->route('category.create')->withErrors($validator);
        }
    }
    //status
    public function status_category(Request $request) {
        $category = Category::findOrFail($request->category_id);
        $category->status = $request->status;
        $category->save();
        return response()->json(['message' => 'Category status updated successfully.']);
    }
    //delete
    public function delete_category($category){
        $catitem = Category::find($category);
        if(empty($catitem)){
            return redirect()->route('category.index')->with('error', "Category doesn't exist.");
        }
        if(!empty($catitem->thumbnail)){
            if (file_exists(public_path('uploads/category/' . $catitem->thumbnail))) {
                unlink(public_path('uploads/category/' . $catitem->thumbnail));
            }
        }
        if(!empty($catitem->banner)){
            if (file_exists(public_path('uploads/category/' . $catitem->banner))) {
                unlink(public_path('uploads/category/' . $catitem->banner));
            }
        }
        $catitem->delete();
        return redirect()->route('category.index')->with('success','Category deleted successfully.');
    }
}
