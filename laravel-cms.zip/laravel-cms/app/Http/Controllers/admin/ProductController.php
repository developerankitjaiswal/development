<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::select('tbl_products.*', 'tbl_categories.name as categoryName')
                        ->leftJoin('tbl_categories', 'tbl_categories.id', '=', 'tbl_products.category_id')
                        ->latest('tbl_products.id')
                        ->get();
        return view('admin.product.view',compact('products'));
    }
    //create
    public function create()
    {
        $categories = Category::where('status', '=', 1)->orderBy('id', 'DESC')->get();
        return view('admin.product.create',compact('categories'));
    }

    //get subcategory
    public function getsubcategory(Request $request){
        if(!empty($request->category_id)){
            $subCategories = Subcategory::select('id', 'name')->where('category_id',$request->category_id)->orderBy('name','ASC')->get();
            return response()->json([
                'status' => true,
                'subcategories' => $subCategories
            ]);
        } else {
            return response()->json([
                'status' => true,
                'subcategories' => []
            ]);
        }
    }
    //create category
    public function store_product(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'slug' => 'required|unique:tbl_products',
            'category' => 'required',
            'thumbnail' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
            'shortdescription' => 'required',
            'status' => 'required',
        ]);
        if ($validator->passes()){
            $pro = new Product;
            /* for multiple image*/
            if($request->hasFile('multimage')){
                $request->validate([
                    'multimage' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $multiImage = 'product_'.time().'.'.$request->multimage->extension();  
                $request->multimage->move(public_path('uploads/product'), $multiImage);
                $pro->images = $multiImage;
            }
             /* for multiple image*/
            $thumbImage = 'thumbnail_'.time().'.'.$request->thumbnail->extension();  
            $request->thumbnail->move(public_path('uploads/product'), $thumbImage);
            $pro->name = $request->name;
            $pro->slug = Str::slug($request->slug);
            $pro->category_id = $request->category;
            $pro->subcategory_id = $request->subcategory;
            $pro->thumbnail = $thumbImage;
            $pro->shortdescription = $request->shortdescription;
            $pro->description = $request->description;
            $pro->status = $request->status;
            $pro->display_order = $request->sort;
            $pro->metatitle = $request->metatitle;
            $pro->metakeyword = $request->metakeyword;
            $pro->metadescription = $request->metadescription;
            $pro->save();
            return redirect()->route('product.create')->with('success','Product has been created successfully.');
        } else {
            return redirect()->route('product.create')->withErrors($validator);
        }
    }
    //edit category
    public function edit_product($productID, Request $request )
    {
        $product = Product::find($productID);
        if(empty($product)){
            return redirect()->route('product.index')->with('error', "Product doesn't exist.");
        }
        $categories = Category::where('status', '=', 1)->orderBy('id', 'DESC')->get();
        return view('admin.product.edit',compact('product','categories'));
    }
    //Update category
    public function update_product($productID, Request $request)
    {
        $product = Product::find($productID);
        if(empty($product)){
            return redirect()->route('product.index')->with('error', "Product doesn't exist.");
        }
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'slug' => 'required|unique:tbl_products,slug,'.$product->id.',id',
            'category' => 'required',
            'shortdescription' => 'required',
            'status' => 'required',
        ]);
        if ($validator->passes()){
            /* for image*/
            if($request->hasFile('thumbnail')){
                $request->validate([
                    'thumbnail' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $thumbImage = 'thumbnail_'.time().'.'.$request->thumbnail->extension();  
                $request->thumbnail->move(public_path('uploads/product'), $thumbImage);
                $product->thumbnail = $thumbImage;
            }
            if($request->hasFile('multimage')){
                $request->validate([
                    'multimage' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                ]);
                $productImage = 'product_'.time().'.'.$request->multimage->extension();  
                $request->multimage->move(public_path('uploads/product'), $productImage);
                $product->images = $productImage;
            }
             /* for image*/
            $product->name = $request->name;
            $product->slug = Str::slug($request->slug);
            $product->category_id = $request->category;
            $product->subcategory_id = $request->subcategory;
            $product->shortdescription = $request->shortdescription;
            $product->description = $request->description;
            $product->status = $request->status;
            $product->display_order = $request->sort;
            $product->metatitle = $request->metatitle;
            $product->metakeyword = $request->metakeyword;
            $product->metadescription = $request->metadescription;
            $product->save();
            return redirect()->route('product.index')->with('success','Product has been updated successfully.');
        } else {
            return redirect()->route('product.index')->withErrors($validator);
        }
    }
    //status
    public function status_product(Request $request) {
        $product = Product::findOrFail($request->product_id);
        $product->status = $request->status;
        $product->save();
        return response()->json(['message' => 'Product status updated successfully.']);
    }
    //delete
    public function delete_product($product){
        $proitem = Product::find($product);
        if(empty($proitem)){
            return redirect()->route('product.index')->with('error', "Product doesn't exist.");
        }
        if(!empty($proitem->thumbnail)){
            if (file_exists(public_path('uploads/product/' . $proitem->thumbnail))) {
                unlink(public_path('uploads/product/' . $proitem->thumbnail));
            }
        }
        if(!empty($proitem->images)){
            if (file_exists(public_path('uploads/product/' . $proitem->images))) {
                unlink(public_path('uploads/product/' . $proitem->images));
            }
        }
        $proitem->delete();
        return redirect()->route('product.index')->with('success','Product deleted successfully.');
    }
}
