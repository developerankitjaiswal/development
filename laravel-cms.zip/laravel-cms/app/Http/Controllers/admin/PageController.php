<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\Page;
use Illuminate\Http\Request;

class PageController extends Controller
{
    /*****************ABOUT****************/
    public function about()
    {
        $pagedata = Page::where('page_name', 'about-us')->where('page_type', 'p')->first();
        return view('admin.pages.about', compact('pagedata'));
    }
    //STORE
    public function store_about(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'title' => 'required|max:255',
            'description' => 'required',
        ]);
        if ($validator->passes()){
            // Check if the page exists in the database
            $page = Page::where('page_name', 'about-us')->where('page_type', 'p')->first();
            if ($page) {
                if($request->hasFile('fileimg')){
                    $request->validate([
                    'fileimg' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                    ],
                    [
                        'fileimg.image' => 'Please select an image file to upload',
                        'fileimg.mimes' => 'Sorry, only JPG, JPEG , PNG & WEBP files are allowed to upload',
                        'fileimg.max' => 'About us image maximum file size to upload is 1MB ',
                    ]);
                    $imageName = 'page_'.time().'.'.$request->fileimg->extension();  
                    $request->fileimg->move(public_path('uploads/other'), $imageName);
                    $page->image = $imageName;
                }
                $page->title = $request->title;
                $page->subtitle = $request->subtitle;
                $page->description = $request->description;
                $page->save();
                return redirect()->route('about.view')->with('success','About Us Updated successfully.');
            } else {
                $page = new Page;
                if($request->hasFile('fileimg')){
                    $request->validate([
                    'fileimg' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                    ],
                    [
                        'fileimg.image' => 'Please select an image file to upload',
                        'fileimg.mimes' => 'Sorry, only JPG, JPEG , PNG & WEBP files are allowed to upload',
                        'fileimg.max' => 'About us image maximum file size to upload is 1MB ',
                    ]);
                    $imageName = 'page_'.time().'.'.$request->fileimg->extension();  
                    $request->fileimg->move(public_path('uploads/other'), $imageName);
                    $page->image = $imageName;
                }
                $page->title = $request->title;
                $page->subtitle = $request->subtitle;
                $page->description = $request->description;
                $page->page_name = 'about-us';
                $page->page_type = 'P';
                $page->save();
                return redirect()->route('about.view')->with('success','About Us has been created successfully.');
            }
        } else {
            return redirect()->route('about.view')->withErrors($validator);
        }
    }
    /***********TERM & CONDITION***********/
    public function termpolicy()
    {
        $pagedata = Page::where('page_name', 'term-condition')->where('page_type', 'p')->first();
        return view('admin.pages.termpolicy', compact('pagedata'));
    }
    //STORE
    public function store_termpolicy(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'title' => 'required|max:255',
            'description' => 'required',
        ]);
        if ($validator->passes()){
            // Check if the page exists in the database
            $page = Page::where('page_name', 'term-condition')->where('page_type', 'p')->first();
            if ($page) {
                if($request->hasFile('fileimg')){
                    $request->validate([
                    'fileimg' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                    ],
                    [
                        'fileimg.image' => 'Please select an image file to upload',
                        'fileimg.mimes' => 'Sorry, only JPG, JPEG , PNG & WEBP files are allowed to upload',
                        'fileimg.max' => 'Image maximum file size to upload is 1MB ',
                    ]);
                    $imageName = 'page_'.time().'.'.$request->fileimg->extension();  
                    $request->fileimg->move(public_path('uploads/other'), $imageName);
                    $page->image = $imageName;
                }
                $page->title = $request->title;
                $page->subtitle = $request->subtitle;
                $page->description = $request->description;
                $page->save();
                return redirect()->route('termpolicy.view')->with('success','Term Policy Updated successfully.');
            } else {
                $page = new Page;
                if($request->hasFile('fileimg')){
                    $request->validate([
                    'fileimg' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                    ],
                    [
                        'fileimg.image' => 'Please select an image file to upload',
                        'fileimg.mimes' => 'Sorry, only JPG, JPEG , PNG & WEBP files are allowed to upload',
                        'fileimg.max' => 'Image maximum file size to upload is 1MB ',
                    ]);
                    $imageName = 'page_'.time().'.'.$request->fileimg->extension();  
                    $request->fileimg->move(public_path('uploads/other'), $imageName);
                    $page->image = $imageName;
                }
                $page->title = $request->title;
                $page->subtitle = $request->subtitle;
                $page->description = $request->description;
                $page->page_name = 'term-condition';
                $page->page_type = 'P';
                $page->save();
                return redirect()->route('termpolicy.view')->with('success','Term Policy has been created successfully.');
            }
        } else {
            return redirect()->route('termpolicy.view')->withErrors($validator);
        }
    }
    /***********RETURN POLICY**************/
    public function returnpolicy()
    {
        $pagedata = Page::where('page_name', 'return-policy')->where('page_type', 'p')->first();
        return view('admin.pages.returnpolicy', compact('pagedata'));
    }
    //STORE
    public function store_returnpolicy(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'title' => 'required|max:255',
            'description' => 'required',
        ]);
        if ($validator->passes()){
            // Check if the page exists in the database
            $page = Page::where('page_name', 'return-policy')->where('page_type', 'p')->first();
            if ($page) {
                if($request->hasFile('fileimg')){
                    $request->validate([
                    'fileimg' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                    ],
                    [
                        'fileimg.image' => 'Please select an image file to upload',
                        'fileimg.mimes' => 'Sorry, only JPG, JPEG , PNG & WEBP files are allowed to upload',
                        'fileimg.max' => 'Image maximum file size to upload is 1MB ',
                    ]);
                    $imageName = 'page_'.time().'.'.$request->fileimg->extension();  
                    $request->fileimg->move(public_path('uploads/other'), $imageName);
                    $page->image = $imageName;
                }
                $page->title = $request->title;
                $page->subtitle = $request->subtitle;
                $page->description = $request->description;
                $page->save();
                return redirect()->route('returnpolicy.view')->with('success','Return Policy Updated successfully.');
            } else {
                $page = new Page;
                if($request->hasFile('fileimg')){
                    $request->validate([
                    'fileimg' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                    ],
                    [
                        'fileimg.image' => 'Please select an image file to upload',
                        'fileimg.mimes' => 'Sorry, only JPG, JPEG , PNG & WEBP files are allowed to upload',
                        'fileimg.max' => 'Image maximum file size to upload is 1MB ',
                    ]);
                    $imageName = 'page_'.time().'.'.$request->fileimg->extension();  
                    $request->fileimg->move(public_path('uploads/other'), $imageName);
                    $page->image = $imageName;
                }
                $page->title = $request->title;
                $page->subtitle = $request->subtitle;
                $page->description = $request->description;
                $page->page_name = 'return-policy';
                $page->page_type = 'P';
                $page->save();
                return redirect()->route('returnpolicy.view')->with('success','Return Policy has been created successfully.');
            }
        } else {
            return redirect()->route('returnpolicy.view')->withErrors($validator);
        }
    }
    /***********Privacy POLICY*************/
    public function privacypolicy()
    {
        $pagedata = Page::where('page_name', 'privacy-policy')->where('page_type', 'p')->first();
        return view('admin.pages.privacypolicy', compact('pagedata'));
    }
    //STORE
    public function store_privacypolicy(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'title' => 'required|max:255',
            'description' => 'required',
        ]);
        if ($validator->passes()){
            // Check if the page exists in the database
            $page = Page::where('page_name', 'privacy-policy')->where('page_type', 'p')->first();
            if ($page) {
                if($request->hasFile('fileimg')){
                    $request->validate([
                    'fileimg' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                    ],
                    [
                        'fileimg.image' => 'Please select an image file to upload',
                        'fileimg.mimes' => 'Sorry, only JPG, JPEG , PNG & WEBP files are allowed to upload',
                        'fileimg.max' => 'Image maximum file size to upload is 1MB ',
                    ]);
                    $imageName = 'page_'.time().'.'.$request->fileimg->extension();  
                    $request->fileimg->move(public_path('uploads/other'), $imageName);
                    $page->image = $imageName;
                }
                $page->title = $request->title;
                $page->subtitle = $request->subtitle;
                $page->description = $request->description;
                $page->save();
                return redirect()->route('privacypolicy.view')->with('success','Privacy Policy Updated successfully.');
            } else {
                $page = new Page;
                if($request->hasFile('fileimg')){
                    $request->validate([
                    'fileimg' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                    ],
                    [
                        'fileimg.image' => 'Please select an image file to upload',
                        'fileimg.mimes' => 'Sorry, only JPG, JPEG , PNG & WEBP files are allowed to upload',
                        'fileimg.max' => 'Image maximum file size to upload is 1MB ',
                    ]);
                    $imageName = 'page_'.time().'.'.$request->fileimg->extension();  
                    $request->fileimg->move(public_path('uploads/other'), $imageName);
                    $page->image = $imageName;
                }
                $page->title = $request->title;
                $page->subtitle = $request->subtitle;
                $page->description = $request->description;
                $page->page_name = 'privacy-policy';
                $page->page_type = 'P';
                $page->save();
                return redirect()->route('privacypolicy.view')->with('success','Privacy Policy has been created successfully.');
            }
        } else {
            return redirect()->route('privacypolicy.view')->withErrors($validator);
        }
    }
}
