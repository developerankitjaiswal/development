<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Banner;
use App\Models\Blog;
use App\Models\Product;
use App\Models\Page;
use App\Models\Category;
use App\Models\Subcategory;
use App\Models\Testimonial;

class FrontController extends Controller
{
    //Home
    public function index(Request $categoryId)
    {
        $showbanner = Banner::where('status','1')->orderBy('display_order', 'ASC')->get();
        $products = Product::where('status','1')->orderBy('display_order', 'ASC')->limit(18)->get();
        $testimonials = Testimonial::where('status','1')->orderBy('display_order', 'ASC')->get();
        //nav dynamic
        $navproducts = Product::where('status','1')->latest()->limit(20)->get();
        $navcategories = Category::where('status','1')->latest()->limit(10)->get();
        //end nav dynamic
        return view('front.index', compact('showbanner','products','navcategories','navproducts','testimonials'));
    }
    //Product
    public function product($slug)
    {
        $category = Category::where('slug',$slug)->where('status','1')->first();
        if(empty($category)){
            return redirect()->route('index')->with('error', "Category doesn't exist.");
        }
        
        $products = [];
        if ($category->category_type == '2') {
            $subcategories = Subcategory::where('category_id', $category->id)->where('status', '1')->get();
            foreach ($subcategories as $subcategory) {
                $subcategoryProducts = Product::where('subcategory_id', $subcategory->id)
                    ->where('status', '1')
                    ->orderBy('display_order', 'ASC')
                    ->paginate(9);
                $products[$subcategory->name] = $subcategoryProducts;
            }
            return view('front.product', compact('products', 'category'));
        } else {
            $products = Product::where('category_id', $category->id)->where('status','1')->orderBy('display_order', 'ASC')->paginate(9);
            return view('front.product',compact('products','category'));
        }
    }
    //Product Detail
    public function productdetail($slug)
    {
        $prodetail = Product::where('slug',$slug)->where('status','1')->first();
        if(empty($prodetail)){
            return redirect()->route('index')->with('error', "Product doesn't exist.");
        }
        $categry = Category::where('id',$prodetail->category_id)->where('status','1')->first();
        return view('front.product-detail', compact('prodetail','categry'));
    }
    //About
    public function about()
    {
        $aboutdata = Page::where('page_name', 'about-us')->where('page_type', 'p')->first();
        return view('front.about', compact('aboutdata'));
    }
    //return_policy
    public function return_policy()
    {
        $returndata = Page::where('page_name', 'return-policy')->where('page_type', 'p')->first();
        return view('front.return-policy', compact('returndata'));
    }
    //term_policy
    public function term_policy()
    {
        $returndata = Page::where('page_name', 'term-condition')->where('page_type', 'p')->first();
        return view('front.term-policy', compact('returndata'));
    }
    //privacy_policy
    public function privacy_policy()
    {
        $returndata = Page::where('page_name', 'privacy-policy')->where('page_type', 'p')->first();
        return view('front.privacy-policy', compact('returndata'));
    }
    //Blog
    public function blog()
    {
        $showblogs = Blog::where('status','1')->orderBy('display_order', 'ASC')->paginate(12);
        return view('front.blog', compact('showblogs'));
    }
    //Blog Detail
    public function blogdetail($slug)
    {
        $blogdetail = Blog::where('slug',$slug)->where('status','1')->first();
        if(empty($blogdetail)){
            return redirect()->route('index')->with('error', "Blog doesn't exist.");
        }
        return view('front.blog-detail',compact('blogdetail'));
    }
    //Faq
    public function faq()
    {
        return view('front.faq');
    }
    //Contact
    public function contact()
    {
        return view('front.contact');
    }

    

    //Contact
    public function dealer()
    {
        return view('front.dealer');
    }

    
}
